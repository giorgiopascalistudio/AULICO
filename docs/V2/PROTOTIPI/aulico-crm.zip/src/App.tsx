/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Societa, Contact, Preventivo, AttivitaTecnico, DocumentoCliente, FlussoMese, CollaboratoreIncentivo } from './types';
import {
  INITIAL_CONTACTS,
  INITIAL_PREVENTIVI,
  INITIAL_ATTIVITA,
  INITIAL_DOCUMENTS,
  INITIAL_FINANCE_DATA,
  COLLABORATORI_INCENTIVO,
  INITIAL_AGENDA_EVENTS,
  INITIAL_BLOG_ARTICLES,
  INITIAL_GADGETS
} from './mockData';

// Subviews
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import RegistroClientiView from './components/RegistroClientiView';
import CommercialeView from './components/CommercialeView';
import AgendaView from './components/AgendaView';
import RegistroAttivitaView from './components/RegistroAttivitaView';
import CestinoView from './components/CestinoView';

export default function App() {
  // Global States (using localStorage for persistence so user won't lose changes)
  const [activeSocieta, setActiveSocieta] = useState<Societa>(Societa.STRATEGICO);
  const [activeView, setActiveView] = useState<string>('registro_clienti');
  const [activeRole, setActiveRole] = useState<string>('Dario Fiore');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [contacts, setContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('aulico_contacts');
    return saved ? JSON.parse(saved) : INITIAL_CONTACTS;
  });

  const [deletedContacts, setDeletedContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('aulico_deleted_contacts');
    return saved ? JSON.parse(saved) : [];
  });

  const [preventivi, setPreventivi] = useState<Preventivo[]>(() => {
    const saved = localStorage.getItem('aulico_preventivi');
    return saved ? JSON.parse(saved) : INITIAL_PREVENTIVI;
  });

  const [attivita, setAttivita] = useState<AttivitaTecnico[]>(() => {
    const saved = localStorage.getItem('aulico_attivita');
    return saved ? JSON.parse(saved) : INITIAL_ATTIVITA;
  });

  const [documents, setDocuments] = useState<DocumentoCliente[]>(() => {
    const saved = localStorage.getItem('aulico_documents');
    return saved ? JSON.parse(saved) : INITIAL_DOCUMENTS;
  });

  const [financeData, setFinanceData] = useState<{ [key in Societa]: FlussoMese[] }>(() => {
    const saved = localStorage.getItem('aulico_finance');
    return saved ? JSON.parse(saved) : INITIAL_FINANCE_DATA;
  });

  const [agendaEvents, setAgendaEvents] = useState<any[]>(() => {
    const saved = localStorage.getItem('aulico_events');
    return saved ? JSON.parse(saved) : INITIAL_AGENDA_EVENTS;
  });

  const [blogArticles, setBlogArticles] = useState<any[]>(() => {
    const saved = localStorage.getItem('aulico_blogs');
    return saved ? JSON.parse(saved) : INITIAL_BLOG_ARTICLES;
  });

  const [gadgets, setGadgets] = useState<any[]>(() => {
    const saved = localStorage.getItem('aulico_gadgets');
    return saved ? JSON.parse(saved) : INITIAL_GADGETS;
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('aulico_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('aulico_deleted_contacts', JSON.stringify(deletedContacts));
  }, [deletedContacts]);

  useEffect(() => {
    localStorage.setItem('aulico_preventivi', JSON.stringify(preventivi));
  }, [preventivi]);

  useEffect(() => {
    localStorage.setItem('aulico_attivita', JSON.stringify(attivita));
  }, [attivita]);

  useEffect(() => {
    localStorage.setItem('aulico_documents', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('aulico_finance', JSON.stringify(financeData));
  }, [financeData]);

  useEffect(() => {
    localStorage.setItem('aulico_events', JSON.stringify(agendaEvents));
  }, [agendaEvents]);

  useEffect(() => {
    localStorage.setItem('aulico_blogs', JSON.stringify(blogArticles));
  }, [blogArticles]);

  useEffect(() => {
    localStorage.setItem('aulico_gadgets', JSON.stringify(gadgets));
  }, [gadgets]);

  // Log auditing mechanism to standard activity log
  const logSystemActivity = (action: string, desc: string, area: string) => {
    const systemLogs = JSON.parse(localStorage.getItem('aulico_system_logs') || '[]');
    const newLog = {
      id: 'log-' + Date.now(),
      azione: action,
      descrizione: desc,
      operatore: activeRole,
      data: new Date().toISOString().replace('T', ' ').slice(0, 16),
      area: area
    };
    localStorage.setItem('aulico_system_logs', JSON.stringify([newLog, ...systemLogs]));
  };

  // Contacts handlers
  const handleAddContact = (contact: Contact) => {
    setContacts([contact, ...contacts]);
    logSystemActivity('Creazione', `Registrato nuovo contatto ${contact.name} ${contact.surname}`, 'Clienti');
  };

  const handleUpdateContact = (updated: Contact) => {
    setContacts(contacts.map((c) => (c.id === updated.id ? updated : c)));
    logSystemActivity('Modifica', `Aggiornata anagrafica contatto ${updated.name} ${updated.surname}`, 'Clienti');
  };

  const handleDeleteContact = (id: string) => {
    const target = contacts.find((c) => c.id === id);
    if (target) {
      setContacts(contacts.filter((c) => c.id !== id));
      setDeletedContacts([target, ...deletedContacts]);
      logSystemActivity('Eliminazione', `Spostato nel cestino ${target.name} ${target.surname}`, 'Clienti');
    }
  };

  const handleRestoreContact = (contact: Contact) => {
    setDeletedContacts(deletedContacts.filter((c) => c.id !== contact.id));
    setContacts([contact, ...contacts]);
    logSystemActivity('Ripristino', `Ripristinato contatto ${contact.name} ${contact.surname} dal cestino`, 'Clienti');
  };

  const handleHardDeleteContact = (id: string) => {
    setDeletedContacts(deletedContacts.filter((c) => c.id !== id));
    logSystemActivity('Eliminazione', `Eliminato definitivamente contatto ID: ${id}`, 'Cestino');
  };

  const handleUpdateContactPhase = (contactId: string, phase: any) => {
    const target = contacts.find((c) => c.id === contactId);
    if (target) {
      const updated = { ...target, fasePipeline: phase };
      setContacts(contacts.map((c) => (c.id === contactId ? updated : c)));
      logSystemActivity('Modifica', `Avanzata fase pipeline per ${target.name} a: ${phase}`, 'Commerciale');
    }
  };

  // Preventivi Handlers
  const handleAddPreventivo = (prev: Preventivo) => {
    setPreventivi([prev, ...preventivi]);
    logSystemActivity('Creazione', `Elaborato preventivo ${prev.codice} - ${prev.titolo}`, 'Commerciale');
  };

  const handleUpdatePreventivo = (updated: Preventivo) => {
    setPreventivi(preventivi.map((p) => (p.id === updated.id ? updated : p)));
    logSystemActivity('Modifica', `Aggiornato preventivo ${updated.codice} stato: ${updated.stato}`, 'Commerciale');
  };

  // Attivita / Tasks Handlers
  const handleAddAttivita = (act: AttivitaTecnico) => {
    setAttivita([act, ...attivita]);
    logSystemActivity('Creazione', `Assegnato compito tecnico automatico a ${act.tecnico}: ${act.titolo}`, 'Commerciale');
  };

  // Documents Handlers
  const handleAddDocument = (doc: DocumentoCliente) => {
    setDocuments([doc, ...documents]);
    logSystemActivity('Creazione', `Caricato documento: ${doc.nome} in ${doc.categoria}`, 'Produzione');
  };

  // Finance Handlers
  const handleUpdateFinanceData = (soc: Societa, data: FlussoMese[]) => {
    setFinanceData({
      ...financeData,
      [soc]: data
    });
    logSystemActivity('Modifica', `Aggiornato piano finanziario per la società ${soc}`, 'Amministrazione');
  };

  // Agenda Event Handlers
  const handleAddAgendaEvent = (ev: any) => {
    setAgendaEvents([ev, ...agendaEvents]);
    logSystemActivity('Creazione', `Registrato appuntamento in agenda per il giorno ${ev.data} alle ore ${ev.ora}`, 'Agenda');
  };

  // Marketing Handlers
  const handleAddGadget = (g: any) => {
    setGadgets([g, ...gadgets]);
    logSystemActivity('Creazione', `Inserito nuovo omaggio in inventario: ${g.nome}`, 'Marketing');
  };

  const handleAddBlogArticle = (a: any) => {
    setBlogArticles([a, ...blogArticles]);
    logSystemActivity('Creazione', `Iniziata stesura articolo blog: ${a.titolo}`, 'Marketing');
  };

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-50 font-sans" id="aulico-app-layout">
      
      {/* Sidebar links */}
      <Sidebar activeView={activeView} onViewChange={setActiveView} activeRole={activeRole} />

      {/* Main Right panel */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden" id="aulico-main-content">
        
        {/* Main top header */}
        <Header
          activeSocieta={activeSocieta}
          onSocietaChange={setActiveSocieta}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          activeRole={activeRole}
          onRoleChange={setActiveRole}
        />

        {/* Dynamic subviews renderer based on active sidebar tab */}
        <main className="flex-1 overflow-hidden min-h-0" id="aulico-view-viewport">
          {activeView === 'registro_clienti' && (
            <RegistroClientiView
              contacts={contacts}
              onAddContact={handleAddContact}
              onUpdateContact={handleUpdateContact}
              onDeleteContact={handleDeleteContact}
              activeSocieta={activeSocieta}
              searchQuery={searchQuery}
            />
          )}

          {activeView === 'commerciale' && (
            <CommercialeView
              contacts={contacts}
              preventivi={preventivi}
              attivita={attivita}
              onAddPreventivo={handleAddPreventivo}
              onUpdatePreventivo={handleUpdatePreventivo}
              onAddAttivita={handleAddAttivita}
              onUpdateContactPhase={handleUpdateContactPhase}
            />
          )}

          {activeView === 'agenda' && (
            <AgendaView
              events={agendaEvents}
              onAddEvent={handleAddAgendaEvent}
            />
          )}

          {activeView === 'registro_attivita' && (
            <RegistroAttivitaView />
          )}

          {activeView === 'cestino' && (
            <CestinoView
              deletedContacts={deletedContacts}
              onRestoreContact={handleRestoreContact}
              onHardDeleteContact={handleHardDeleteContact}
            />
          )}
        </main>
      </div>

    </div>
  );
}
