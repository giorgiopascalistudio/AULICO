/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Societa, Contact, Preventivo, AttivitaTecnico, DocumentoCliente, FlussoMese, CollaboratoreIncentivo } from './types';

export const INITIAL_COLLABORATORI = [
  'Francesco Zurlo',
  'Davide Ciracì',
  'Raffaele Zivoli',
  'Claudia Turco',
  'Marco Epifani',
  'Ilaria Cavallo',
  'Vitania Rubino',
  'Pascali Giorgio',
  'Argentiero Mino',
  'Dario Fiore'
];

export const INITIAL_CONTACTS: Contact[] = [
  {
    id: 'gioia-mariagrazia',
    name: 'Mariagrazia',
    surname: 'Gioia',
    companyName: 'Gioia Costruzioni SRL',
    cfPiva: 'IT01234567890',
    email: 'm.gioia@gioiacostruzioni.it',
    phone: '+39 339 818 0533',
    indirizzo: 'C.da Vado Aperto sn, 72017 Ostuni',
    societaCollegate: [Societa.ONIRICO, Societa.MATERICO],
    categoria: 'Clienti',
    statoCliente: 'attivo',
    targetCategoria: 'Privati con piscina',
    fasciaImportanza: 1,
    canaleAcquisizione: 'agenzia',
    brandAsset: {
      obiettivi: 'Posizionamento di lusso nel mercato delle ville ad Ostuni.',
      tonoVoce: 'Elegante, Minimale, Esclusivo',
      targetRiferimento: 'Investitori Nord-Europei',
      assetGrafici: ['Logo_Gioia.png', 'Viste_3D_Cantiere.zip', 'Moodboard_Materiali_Materico.pdf']
    },
    credenziali: [
      { id: 'c1', service: 'Dropbox Cantiere', username: 'gioia.ostuni', password: 'PasswordSicura123!', note: 'Contiene i rilievi 3D' },
      { id: 'c2', service: 'Portale SUE', username: 'm_gioia_sue', password: 'SUE_password_2026', note: 'Pratica edilizia CILA' }
    ],
    liberatoriaPrivacyFirmata: false, // ALERT ROSSO BLOCCANTE! "NON PUBBLICARE NULLA"
    interazioni: [
      { id: 'i1', tipo: 'riunione', data: '2026-06-15', titolo: 'Minute Riunione di Cantiere', descrizione: 'Sintesi approvazione finiture in pietra e tracciamento scavi piscina.' },
      { id: 'i2', tipo: 'regalo', data: '2025-12-20', titolo: 'Regalo di Natale', descrizione: 'Cesto di prodotti tipici locali pugliesi spedito con successo.', dettagliAggiuntivi: 'Pensiero di Natale' },
      { id: 'i3', tipo: 'campagna', data: '2026-05-10', titolo: 'Invito Inaugurazione', descrizione: 'Inviata newsletter per l\'inaugurazione del nuovo showroom.', dettagliAggiuntivi: 'Campagna Onirico Design' }
    ],
    fasePipeline: 'negoziazione',
    valorePipeline: 145000,
    regolaritaPagamenti: false, // BOLLINO ROSSO! Blocca lo scaricamento di documenti sensibili (es. agibilità)
    saldoDovuto: 24500,
    dataCreazione: '2025-09-15',
    progettoId: 'proj-gioia'
  },
  {
    id: 'ayroldi-maria',
    name: 'Maria',
    surname: 'Ayroldi',
    companyName: 'Ayroldi Boutique',
    cfPiva: 'IT09876543211',
    email: 'ayroldi.maria@gmail.com',
    phone: '+39 338 652 0359',
    indirizzo: 'Piazza Avv. Gino Zaccaria 3, Martina Franca',
    societaCollegate: [Societa.STRATEGICO, Societa.UNICO],
    categoria: 'Clienti',
    statoCliente: 'attivo',
    targetCategoria: 'Attività commerciali',
    fasciaImportanza: 3,
    canaleAcquisizione: 'passaparola',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [
      { id: 'i4', tipo: 'riunione', data: '2026-06-20', titolo: 'Scelta finiture arredi', descrizione: 'Sintesi approvazione layout espositivo e banchi cassa.' }
    ],
    fasePipeline: 'contratto_firmato',
    valorePipeline: 58000,
    regolaritaPagamenti: true, // BOLLINO VERDE
    saldoDovuto: 0,
    dataCreazione: '2024-09-23'
  },
  {
    id: 'bichard-james',
    name: 'James',
    surname: 'Bichard',
    companyName: 'Bichard Investments',
    cfPiva: 'GB773918237',
    email: 'jim.bichard@pwc.com',
    phone: '+39 347 123 4567',
    indirizzo: 'Pezze Sant\'Angelo - Ceglie Messapica',
    societaCollegate: [Societa.STRATEGICO, Societa.UNICO, Societa.ONIRICO],
    categoria: 'Investitori',
    investitoreTipo: 'attivo',
    targetCategoria: 'Investitori Esteri Alta Capacità',
    fasciaImportanza: 1,
    canaleAcquisizione: 'social',
    liberatoriaPrivacyFirmata: true,
    credenziali: [
      { id: 'c3', service: 'Investor Portal', username: 'j_bichard', password: 'PwC_password_2026', note: 'Credenziali portale' }
    ],
    interazioni: [
      { id: 'i5', tipo: 'evento', data: '2026-05-18', titolo: 'Meeting Investitori Ostuni', descrizione: 'Presentazione pacchetto acquisizioni immobiliari in Valle d\'Itria.' }
    ],
    fasePipeline: 'contratto_firmato',
    valorePipeline: 350000,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2025-06-15'
  },
  {
    id: 'bennardo-gianluca',
    name: 'Gianluca',
    surname: 'Bennardo',
    email: 'bennardo.gianluca@gmail.com',
    phone: '+39 371 418 1135',
    indirizzo: 'C.da Bagnardi - Ostuni',
    societaCollegate: [Societa.ONIRICO, Societa.FANTASTICO],
    categoria: 'Clienti',
    statoCliente: 'attivo',
    targetCategoria: 'Imprese di Ostuni',
    fasciaImportanza: 3,
    canaleAcquisizione: 'sito',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [],
    fasePipeline: 'attesa_preventivo',
    valorePipeline: 45000,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2025-03-10'
  },
  {
    id: 'sub-mastro-antonio',
    name: 'Antonio',
    surname: 'Saponaro (Mastro)',
    companyName: 'Saponaro Costruzioni & Pietra',
    cfPiva: 'IT05553334449',
    email: 'mastro.antonio@saponaropietra.it',
    phone: '+39 333 998 8112',
    indirizzo: 'Via per Ceglie km 2, Ostuni',
    societaCollegate: [Societa.MATERICO, Societa.ONIRICO],
    categoria: 'Fornitori e Imprese',
    fornitoreTipo: 'subappaltatore',
    targetCategoria: 'Artigiani Locali e Posatori di Pietra',
    fasciaImportanza: 2,
    canaleAcquisizione: 'passaparola',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [
      { id: 'i6', tipo: 'riunione', data: '2026-06-02', titolo: 'Accordo posa pietra a secco', descrizione: 'Accordo per la fornitura e posa di muretti a secco per il cantiere Gioia.' }
    ],
    fasePipeline: 'contratto_firmato',
    valorePipeline: 0,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2025-01-10'
  },
  {
    id: 'agenzia-pugliadream',
    name: 'Vincenzo',
    surname: 'Sanzò',
    companyName: 'Puglia Dream Real Estate',
    cfPiva: 'IT04445556667',
    email: 'info@pugliadream.com',
    phone: '+39 0831 998822',
    indirizzo: 'Corso Maggiore 45, Ostuni',
    societaCollegate: [Societa.STRATEGICO, Societa.FANTASTICO],
    categoria: 'Agenzie Immobiliari',
    targetCategoria: 'Agenzie immobiliari di lusso',
    fasciaImportanza: 2,
    canaleAcquisizione: 'sito',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [],
    fasePipeline: 'primo_contatto',
    valorePipeline: 0,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2025-11-05'
  },
  {
    id: 'sindaco-ostuni',
    name: 'Angelo',
    surname: 'Pomes',
    companyName: 'Comune di Ostuni',
    email: 'sindaco@comune.ostuni.br.it',
    phone: '+39 0831 307111',
    indirizzo: 'Piazza della Libertà, Ostuni',
    societaCollegate: [Societa.STRATEGICO, Societa.UNICO, Societa.ONIRICO, Societa.MATERICO, Societa.FANTASTICO],
    categoria: 'Figure Istituzionali',
    targetCategoria: 'Amministratori Comunali',
    fasciaImportanza: 1,
    canaleAcquisizione: 'altro',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [
      { id: 'i7', tipo: 'evento', data: '2026-06-18', titolo: 'Incontro su Rigenerazione Urbana', descrizione: 'Discussione sulle opportunità di sviluppo sostenibile nel territorio di Ostuni.' }
    ],
    fasePipeline: 'primo_contatto',
    valorePipeline: 0,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2026-01-15'
  },
  {
    id: 'sponsor-lariccia',
    name: 'Pietro',
    surname: 'La Riccia',
    companyName: 'BCC San Marzano',
    email: 'pietro.lariccia@bcc.it',
    phone: '+39 349 998 8776',
    indirizzo: 'Via per Grottaglie, San Marzano di San Giuseppe',
    societaCollegate: [Societa.STRATEGICO, Societa.ONIRICO],
    categoria: 'Sponsor e Conoscenti',
    targetCategoria: 'Sponsor & Promotori Finanziari',
    fasciaImportanza: 2,
    canaleAcquisizione: 'passaparola',
    liberatoriaPrivacyFirmata: true,
    credenziali: [],
    interazioni: [
      { id: 'i8', tipo: 'regalo', data: '2025-12-15', titolo: 'Pacco Natalizio Speciale', descrizione: 'Inviato pacco di lusso con magnum di vino locale.', dettagliAggiuntivi: 'Pensiero di Natale' }
    ],
    fasePipeline: 'contratto_firmato',
    valorePipeline: 0,
    regolaritaPagamenti: true,
    saldoDovuto: 0,
    dataCreazione: '2025-05-12'
  }
];

export const INITIAL_PREVENTIVI: Preventivo[] = [
  {
    id: 'prev-1',
    contactId: 'gioia-mariagrazia',
    codice: 'PREV-2026-001',
    titolo: 'Progetto Costruzione Villa con Piscina C.da Vado Aperto',
    dataCreazione: '2026-05-10',
    dataScadenza: '2026-08-10',
    importo: 145000,
    stato: 'elaborato',
    archiviato: false,
    firmaOtp: false, // Non ancora firmato OTP
    tecnicoAssegnato: 'Raffaele Zivoli'
  },
  {
    id: 'prev-2',
    contactId: 'ayroldi-maria',
    codice: 'PREV-2025-045',
    titolo: 'Arredo Su Misura Boutique Piazza Zaccaria',
    dataCreazione: '2025-08-12',
    dataScadenza: '2025-11-12',
    importo: 58000,
    stato: 'accettato',
    archiviato: false,
    firmaOtp: true, // Firmato OTP
    tecnicoAssegnato: 'Claudia Turco'
  },
  {
    id: 'prev-3',
    contactId: 'bennardo-gianluca',
    codice: 'PREV-2026-015',
    titolo: 'Consulenza Direzione Lavori C.da Bagnardi',
    dataCreazione: '2026-03-01',
    dataScadenza: '2026-06-01',
    importo: 12000,
    stato: 'scaduto',
    archiviato: true,
    firmaOtp: false,
    tecnicoAssegnato: 'Ilaria Cavallo'
  }
];

export const INITIAL_ATTIVITA: AttivitaTecnico[] = [
  { id: 'act-1', titolo: 'Studio di Fattibilità - Gioia Mariagrazia', tecnico: 'Raffaele Zivoli', scadenza: '2026-07-15', completata: false, contactId: 'gioia-mariagrazia' },
  { id: 'act-2', titolo: 'Analisi Costi Preliminare - Gioia Mariagrazia', tecnico: 'Davide Ciracì', scadenza: '2026-07-20', completata: false, contactId: 'gioia-mariagrazia' },
  { id: 'act-3', titolo: 'Rilievo Topografico - Ayroldi Maria', tecnico: 'Marco Epifani', scadenza: '2025-09-01', completata: true, contactId: 'ayroldi-maria' },
  { id: 'act-4', titolo: 'Progettazione 3D Layout - Ayroldi Maria', tecnico: 'Claudia Turco', scadenza: '2025-09-15', completata: true, contactId: 'ayroldi-maria' }
];

export const INITIAL_DOCUMENTS: DocumentoCliente[] = [
  { id: 'doc-1', nome: '01_Inquadramento_Urbanistico_Firmato.pdf', categoria: '01-Inquadramento', sensibile: false, dataCaricamento: '2025-09-29 18:30', tipo: 'PDF', size: '2.4 MB' },
  { id: 'doc-2', nome: '02_Rilievi_Fotogrammetrici_Drone.dwg', categoria: '02-Rilievi', sensibile: false, dataCaricamento: '2025-09-29 18:32', tipo: 'DWG', size: '14.8 MB' },
  { id: 'doc-3', nome: '03_Tavola_Progetto_Architettonico_Piscina.pdf', categoria: '03-Progetti', sensibile: false, dataCaricamento: '2025-09-29 18:47', tipo: 'PDF', size: '8.1 MB' },
  { id: 'doc-4', nome: '04_Pratica_Edilizia_SUE_CILA.pdf', categoria: '04-Pratiche', sensibile: true, dataCaricamento: '2025-09-29 19:00', tipo: 'PDF', size: '3.2 MB' },
  { id: 'doc-5', nome: '12_Certificato_Agibilità_Ostuni.pdf', categoria: '12-Agibilità', sensibile: true, dataCaricamento: '2025-09-29 19:29', tipo: 'PDF', size: '1.1 MB' } // SENSITIVE BLOCKED FOR MOROSI!
];

// 6 months cash flow projection (as in Screenshots and OCR)
export const INITIAL_FINANCE_DATA: { [key in Societa]: FlussoMese[] } = {
  [Societa.STRATEGICO]: [
    { mese: 'Gennaio', preventivato: 120000, venduto: 95000, fatturato: 80000, incassato: 75000, erogato: 70000, liquidita: 150000, costiFissi: 25000, costiVariabili: 40000 },
    { mese: 'Febbraio', preventivato: 130000, venduto: 110000, fatturato: 90000, incassato: 85000, erogato: 75000, liquidita: 160000, costiFissi: 25000, costiVariabili: 45000 },
    { mese: 'Marzo', preventivato: 140000, venduto: 115000, fatturato: 95000, incassato: 90000, erogato: 80000, liquidita: 170000, costiFissi: 25000, costiVariabili: 48000 },
    { mese: 'Aprile', preventivato: 150000, venduto: 120000, fatturato: 105000, incassato: 100000, erogato: 85000, liquidita: 185000, costiFissi: 25000, costiVariabili: 50000 },
    { mese: 'Maggio', preventivato: 160000, venduto: 130000, fatturato: 110000, incassato: 105000, erogato: 90000, liquidita: 200000, costiFissi: 25000, costiVariabili: 55000 },
    { mese: 'Giugno', preventivato: 180000, venduto: 150000, fatturato: 130000, incassato: 120000, erogato: 100000, liquidita: 220000, costiFissi: 25000, costiVariabili: 65000 }
  ],
  [Societa.UNICO]: [
    { mese: 'Gennaio', preventivato: 80000, venduto: 70000, fatturato: 60000, incassato: 55000, erogato: 50000, liquidita: 90000, costiFissi: 15000, costiVariabili: 30000 },
    { mese: 'Febbraio', preventivato: 85000, venduto: 75000, fatturato: 65000, incassato: 60000, erogato: 55000, liquidita: 95000, costiFissi: 15000, costiVariabili: 32000 },
    { mese: 'Marzo', preventivato: 90000, venduto: 80000, fatturato: 70000, incassato: 65000, erogato: 60000, liquidita: 100000, costiFissi: 15000, costiVariabili: 35000 },
    { mese: 'Aprile', preventivato: 95000, venduto: 85000, fatturato: 75000, incassato: 70000, erogato: 65000, liquidita: 105000, costiFissi: 15000, costiVariabili: 38000 },
    { mese: 'Maggio', preventivato: 100000, venduto: 90000, fatturato: 80000, incassato: 75000, erogato: 70000, liquidita: 110000, costiFissi: 15000, costiVariabili: 40000 },
    { mese: 'Giugno', preventivato: 110000, venduto: 100000, fatturato: 90000, incassato: 85000, erogato: 75000, liquidita: 120000, costiFissi: 15000, costiVariabili: 45000 }
  ],
  [Societa.ONIRICO]: [
    { mese: 'Gennaio', preventivato: 200000, venduto: 180000, fatturato: 150000, incassato: 140000, erogato: 130000, liquidita: 300000, costiFissi: 40000, costiVariabili: 80000 },
    { mese: 'Febbraio', preventivato: 220000, venduto: 190000, fatturato: 160000, incassato: 150000, erogato: 140000, liquidita: 310000, costiFissi: 40000, costiVariabili: 85000 },
    { mese: 'Marzo', preventivato: 240000, venduto: 210000, fatturato: 180000, incassato: 170000, erogato: 150000, liquidita: 330000, costiFissi: 40000, costiVariabili: 90000 },
    { mese: 'Aprile', preventivato: 250000, venduto: 220000, fatturato: 190000, incassato: 180000, erogato: 160000, liquidita: 350000, costiFissi: 40000, costiVariabili: 95000 },
    { mese: 'Maggio', preventivato: 270000, venduto: 240000, fatturato: 210000, incassato: 200000, erogato: 180000, liquidita: 370000, costiFissi: 40000, costiVariabili: 100000 },
    { mese: 'Giugno', preventivato: 300000, venduto: 270000, fatturato: 240000, incassato: 230000, erogato: 200000, liquidita: 400000, costiFissi: 40000, costiVariabili: 110000 }
  ],
  [Societa.MATERICO]: [
    { mese: 'Gennaio', preventivato: 150000, venduto: 120000, fatturato: 100000, incassato: 95000, erogato: 90000, liquidita: 200000, costiFissi: 30000, costiVariabili: 50000 },
    { mese: 'Febbraio', preventivato: 160000, venduto: 130000, fatturato: 110000, incassato: 105000, erogato: 95000, liquidita: 210000, costiFissi: 30000, costiVariabili: 55000 },
    { mese: 'Marzo', preventivato: 170000, venduto: 140000, fatturato: 120000, incassato: 110000, erogato: 100000, liquidita: 220000, costiFissi: 30000, costiVariabili: 60000 },
    { mese: 'Aprile', preventivato: 180000, venduto: 150000, fatturato: 130000, incassato: 120000, erogato: 110000, liquidita: 230000, costiFissi: 30000, costiVariabili: 65000 },
    { mese: 'Maggio', preventivato: 190000, venduto: 160000, fatturato: 140000, incassato: 130000, erogato: 120000, liquidita: 240000, costiFissi: 30000, costiVariabili: 70000 },
    { mese: 'Giugno', preventivato: 210000, venduto: 180000, fatturato: 150000, incassato: 140000, erogato: 130000, liquidita: 250000, costiFissi: 30000, costiVariabili: 80000 }
  ],
  [Societa.FANTASTICO]: [
    { mese: 'Gennaio', preventivato: 90000, venduto: 80000, fatturato: 70000, incassato: 65000, erogato: 60000, liquidita: 100000, costiFissi: 18000, costiVariabili: 35000 },
    { mese: 'Febbraio', preventivato: 95000, venduto: 85000, fatturato: 75000, incassato: 70000, erogato: 65000, liquidita: 105000, costiFissi: 18000, costiVariabili: 38000 },
    { mese: 'Marzo', preventivato: 100000, venduto: 90000, fatturato: 80000, incassato: 75000, erogato: 70000, liquidita: 110000, costiFissi: 18000, costiVariabili: 40000 },
    { mese: 'Aprile', preventivato: 105000, venduto: 95000, fatturato: 85000, incassato: 80000, erogato: 75000, liquidita: 115000, costiFissi: 18000, costiVariabili: 42000 },
    { mese: 'Maggio', preventivato: 110000, venduto: 100000, fatturato: 90000, incassato: 85000, erogato: 80000, liquidita: 120000, costiFissi: 18000, costiVariabili: 45000 },
    { mese: 'Giugno', preventivato: 120000, venduto: 110000, fatturato: 100000, incassato: 95000, erogato: 85000, liquidita: 130000, costiFissi: 18000, costiVariabili: 50000 }
  ]
};

// Points earned monthly by each collaborator (Incentive Plan) as in Page 25
export const COLLABORATORI_INCENTIVO: CollaboratoreIncentivo[] = [
  {
    nome: 'Vitania Rubino',
    puntiMese: { Gennaio: 0, Febbraio: 0, Marzo: 0, Aprile: 0, Maggio: 228, Giugno: 288, Luglio: 304, Agosto: 161, Settembre: 284, Ottobre: 0, Novembre: 0, Dicembre: 0 }
  },
  {
    nome: 'Claudia Turco',
    puntiMese: { Gennaio: 0, Febbraio: 0, Marzo: 0, Aprile: 0, Maggio: 203, Giugno: 211, Luglio: 266, Agosto: 105, Settembre: 253, Ottobre: 0, Novembre: 0, Dicembre: 0 }
  },
  {
    nome: 'Raffaele Zivoli',
    puntiMese: { Gennaio: 0, Febbraio: 0, Marzo: 0, Aprile: 0, Maggio: 261, Giugno: 255, Luglio: 306, Agosto: 91, Settembre: 259, Ottobre: 0, Novembre: 0, Dicembre: 0 }
  },
  {
    nome: 'Marco Epifani',
    puntiMese: { Gennaio: 0, Febbraio: 0, Marzo: 0, Aprile: 0, Maggio: 242, Giugno: 210, Luglio: 216, Agosto: 157, Settembre: 207, Ottobre: 0, Novembre: 0, Dicembre: 0 }
  },
  {
    nome: 'Ilaria Cavallo',
    puntiMese: { Gennaio: 0, Febbraio: 0, Marzo: 0, Aprile: 0, Maggio: 152, Giugno: 195, Luglio: 201, Agosto: 115, Settembre: 258, Ottobre: 0, Novembre: 0, Dicembre: 0 }
  }
];

export const INITIAL_AGENDA_EVENTS = [
  { id: 'ev-1', data: '2026-06-22', ora: '10:00', titolo: 'Sopralluogo Ostuni', tecnico: 'Raffaele Zivoli', cliente: 'Gioia Mariagrazia' },
  { id: 'ev-2', data: '2026-06-23', ora: '15:30', titolo: 'Presentazione Campioni Materico', tecnico: 'Francesco Zurlo', cliente: 'Gioia Mariagrazia' },
  { id: 'ev-3', data: '2026-06-24', ora: '09:00', titolo: 'Verifica SUE / Comune', tecnico: 'Marco Epifani', cliente: 'Comune di Ostuni' },
  { id: 'ev-4', data: '2026-06-25', ora: '11:00', titolo: 'Riunione di Budget', tecnico: 'Davide Ciracì', cliente: 'James Bichard' },
  { id: 'ev-5', data: '2026-06-26', ora: '16:00', titolo: 'Firma contratto OTP', tecnico: 'Claudia Turco', cliente: 'Ayroldi Maria' }
];

export const INITIAL_BLOG_ARTICLES = [
  { id: 'b-1', titolo: 'Ristrutturare un trullo ad Ostuni: regole e permessi', stato: 'In Redazione', data: '2026-06-15', autore: 'Francesco Zurlo' },
  { id: 'b-2', titolo: 'La bellezza della pietra locale: il brand Materico si racconta', stato: 'Pubblicato', data: '2026-05-10', autore: 'Rosa Custodero' }
];

export const INITIAL_GADGETS = [
  { id: 'g-1', nome: 'Borsa termica brandizzata Onirico', quantita: 150, evento: 'Summer Event 2026', consegnati: 120 },
  { id: 'g-2', nome: 'Pacco di Natale con bottiglia Riserva', quantita: 80, evento: 'Natale 2025', consegnati: 80 }
];
