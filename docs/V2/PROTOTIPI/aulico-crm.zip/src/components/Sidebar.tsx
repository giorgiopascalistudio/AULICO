/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Calendar,
  Layers,
  MapPin,
  TrendingUp,
  Megaphone,
  Briefcase,
  FileSpreadsheet,
  Users,
  Search,
  ClipboardList,
  Trash2,
  Building,
  UserCheck
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  activeRole: string;
}

export default function Sidebar({ activeView, onViewChange, activeRole }: SidebarProps) {
  const menuItems = [
    { id: 'registro_clienti', label: 'Registro Clienti', icon: Users },
    { id: 'commerciale', label: 'Pipeline Commerciale', icon: TrendingUp },
    { id: 'agenda', label: 'Agenda & Sopralluoghi', icon: Calendar },
    { id: 'registro_attivita', label: 'Registro Attività', icon: ClipboardList },
    { id: 'cestino', label: 'Cestino', icon: Trash2 },
  ];

  // Get initials for current logged-in role
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  return (
    <aside className="w-64 bg-white border-r border-zinc-100 flex flex-col h-screen shrink-0" id="aulico-sidebar">
      {/* Logo */}
      <div className="p-6 border-b border-zinc-50" id="sidebar-logo-container">
        <div className="flex items-center gap-3">
          <div className="bg-zinc-950 text-white rounded-xl h-10 w-10 flex items-center justify-center font-bold text-xl tracking-tighter">
            Au
          </div>
          <div>
            <h1 className="text-xl font-bold text-zinc-950 tracking-tight leading-none">Aulico</h1>
            <span className="text-[10px] text-zinc-400 uppercase tracking-widest font-semibold">WORKSPACE</span>
          </div>
        </div>
      </div>

      {/* Navigation list */}
      <nav className="flex-1 overflow-y-auto px-4 py-6 space-y-1" id="sidebar-nav">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-zinc-950 text-white shadow-sm'
                  : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-50'
              }`}
              id={`nav-item-${item.id}`}
            >
              <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-zinc-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* User profile section */}
      <div className="p-4 border-t border-zinc-100 bg-zinc-50/50" id="sidebar-user-footer">
        <div className="flex items-center gap-3 bg-white p-3 rounded-xl border border-zinc-100 shadow-sm">
          <div className="h-9 w-9 rounded-full bg-zinc-900 text-white flex items-center justify-center text-xs font-bold font-mono">
            {getInitials(activeRole)}
          </div>
          <div className="overflow-hidden">
            <h4 className="text-xs font-semibold text-zinc-900 truncate">{activeRole}</h4>
            <span className="text-[10px] text-zinc-400 font-medium block">
              {activeRole === 'Dario Fiore' ? 'Project Manager' : 'Team Collaborator'}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
