/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  Car,
  PiggyBank,
  Sparkles,
  Award,
  ShieldAlert,
  Gift,
  Scale,
  Lock,
  ChevronDown,
  ChevronUp,
  CheckSquare,
  Square
} from 'lucide-react';
import { motion } from 'motion/react';

interface FiscalTopic {
  id: number;
  title: string;
  icon: any;
  desc: string;
  advice: string;
  checklist: string[];
}

const FISCAL_TOPICS: FiscalTopic[] = [
  {
    id: 1,
    title: '1. Forma Giuridica',
    icon: Building2,
    desc: 'Scegliere la struttura societaria corretta per ottimizzare l\'impatto fiscale.',
    advice: 'Per la tipologia di volume d\'affari del gruppo Aulico, la trasformazione delle controllate in SRL con consolidato fiscale di gruppo permette l\'abbattimento dell\'aliquota IRES media ed evita la responsabilità illimitata dei soci.',
    checklist: [
      'Valutazione adeguatezza capitale sociale',
      'Consolidato fiscale holding-controllate',
      'Pianificazione distribuzione utili ad aliquota ridotta'
    ]
  },
  {
    id: 2,
    title: '2. Gestione Automezzi',
    icon: Car,
    desc: 'Fermare l\'emorragia dei costi e ottimizzare la detrazione delle vetture aziendali.',
    advice: 'Configurare il noleggio a lungo termine ad uso promiscuo per i tecnici del cantiere, massimizzando la deducibilità dei costi al 70-80% e riducendo l\'IVA non detraibile al minimo.',
    checklist: [
      'Verifica contratti noleggio agenti e tecnici',
      'Calcolo fringe benefit in busta paga',
      'Scrittura regolamento car policy interna'
    ]
  },
  {
    id: 3,
    title: '3. TFM (Trattamento Fine Mandato)',
    icon: PiggyBank,
    desc: 'La cassaforte dell\'amministratore ad aliquota agevolata.',
    advice: 'Accantonare annualmente quote di TFM per gli amministratori di Onirico e Strategico. L\'importo è interamente deducibile per la società come costo per servizi e gode di tassazione separata agevolata per il beneficiario.',
    checklist: [
      'Delibera assembleare con data certa prima dell\'inizio del mandato',
      'Scelta polizza assicurativa di accantonamento',
      'Definizione percentuale sul compenso annuo'
    ]
  },
  {
    id: 4,
    title: '4. Royalties e Marchio',
    icon: Sparkles,
    desc: 'Ottimizzare il prelievo sfruttando il valore dell\'ingegno.',
    advice: 'Registrare il marchio "Aulico" e "Onirico" a livello personale e concederlo in licenza d\'uso alle società operative. I compensi per royalties beneficiano di una deduzione forfettaria del 25-40% esente da contributi INPS.',
    checklist: [
      'Registrazione marchio presso UIBM con data certa',
      'Perizia di stima del valore del marchio commerciale',
      'Contratto di licenza d\'uso registrato all\'Agenzia delle Entrate'
    ]
  },
  {
    id: 5,
    title: '5. Finanza Agevolata',
    icon: Award,
    desc: 'Crediti d\'imposta strategici per investimenti tecnologici.',
    advice: 'Sfruttare i crediti d\'imposta Transizione 5.0 e Ricerca & Sviluppo per l\'acquisizione di software di progettazione 3D tridimensionale e droni utilizzati per i rilievi fotografici dei cantieri.',
    checklist: [
      'Analisi investimenti in beni strumentali materiali/immateriali',
      'Relazione tecnica giurata asseverata da ingegnere terzo',
      'Compensazione F24 tramite codice tributo dedicato'
    ]
  },
  {
    id: 6,
    title: '6. Previdenza Integrativa',
    icon: ShieldAlert,
    desc: 'Lo scudo fiscale personale degli amministratori e soci.',
    advice: 'Dedurre dal reddito personale fino a 5.164,57 € all\'anno tramite versamenti in fondi pensionistici integrativi aziendali. Un modo sicuro per ridurre lo scaglione IRPEF personale dell\'amministratore.',
    checklist: [
      'Scelta fondo pensione di categoria o aperto',
      'Configurazione bonifico ricorrente pre-IRPEF',
      'Dichiarazione dei contributi dedotti nel modello Unico'
    ]
  },
  {
    id: 7,
    title: '7. Buoni Regalo',
    icon: Gift,
    desc: 'Welfare aziendale e rappresentanza deducibili al 100%.',
    advice: 'Erogare fringe benefit fino a 1.000 € (o 2.000 € per dipendenti con figli) in buoni benzina o spesa. Sono interamente esenti da tasse e contributi sia per l\'azienda che per il collaboratore.',
    checklist: [
      'Emissione buoni pasto cartacei o elettronici giornalieri',
      'Attribuzione buoni acquisto omaggio Natale ai dipendenti',
      'Verifica dei limiti di soglia annuale per codice fiscale'
    ]
  },
  {
    id: 8,
    title: '8. Gestione INPS',
    icon: Scale,
    desc: 'Disinnescare la doppia contribuzione commercianti/gestione separata.',
    advice: 'Dimostrare la prevalenza del ruolo di puro amministratore intellettuale rispetto all\'operatività commerciale quotidiana per evitare l\'iscrizione d\'ufficio alla doppia gestione INPS Artigiani/Commercianti.',
    checklist: [
      'Analisi statuto e oggetto sociale delle controllate',
      'Configurazione corretto inquadramento INPS Gestione Separata',
      'Raccolta prove dell\'attività svolta dai dipendenti operativi'
    ]
  },
  {
    id: 9,
    title: '9. La Holding',
    icon: Building2,
    desc: 'La fortezza per la protezione ed il reinvestimento del patrimonio.',
    advice: 'Raggruppare Onirico, Strategico, Materico, Unico e Fantastico sotto una Holding di famiglia (H) che beneficia della direttiva PEX (Partecipation Exemption): gli utili transitano alla Holding tassati solo al 1.2% pronti per essere reinvestiti.',
    checklist: [
      'Costituzione Holding srl di famiglia sopra le controllate',
      'Conferimento partecipazioni ai sensi dell\'art. 177 comma 2-bis TUIR',
      'Pianificazione reinvestimento in asset immobiliari protetti'
    ]
  }
];

export default function PianificazioneFiscaleView() {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [checkedItems, setCheckedItems] = useState<{ [key: string]: boolean }>({});

  const toggleCheck = (id: number, index: number) => {
    const key = `${id}-${index}`;
    setCheckedItems((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-zinc-50" id="pianificazione-fiscale-module">
      
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-zinc-950 tracking-tight">Pianificazione Fiscale Avanzata</h2>
        <p className="text-xs text-zinc-400 mt-1">
          Bento board strategico per monitorare e disinnescare la pressione fiscale del gruppo Aulico.
        </p>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="fiscale-bento-grid">
        {FISCAL_TOPICS.map((topic) => {
          const Icon = topic.icon;
          const isExpanded = expandedId === topic.id;
          
          return (
            <div
              key={topic.id}
              className={`bg-white rounded-2xl border border-zinc-200/60 p-5 shadow-2xs hover:shadow-xs transition-all duration-300 flex flex-col justify-between ${
                isExpanded ? 'ring-2 ring-zinc-950 scale-[1.01] lg:col-span-2' : ''
              }`}
              id={`fiscal-card-${topic.id}`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="h-10 w-10 bg-zinc-900 text-white rounded-xl flex items-center justify-center">
                    <Icon className="h-5 w-5" />
                  </div>
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : topic.id)}
                    className="text-zinc-400 hover:text-zinc-950 p-1.5 rounded-full hover:bg-zinc-100 transition-colors"
                  >
                    {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </button>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-zinc-950">{topic.title}</h3>
                  <p className="text-xs text-zinc-400 mt-0.5">{topic.desc}</p>
                </div>

                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="pt-3 border-t border-zinc-100 space-y-4"
                  >
                    <div>
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">Consulenza Strategica Aulico</span>
                      <p className="text-xs text-zinc-700 leading-relaxed mt-1 bg-zinc-50 p-3 rounded-lg border border-zinc-100 font-medium">
                        {topic.advice}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block">Adempimenti & Checklist</span>
                      <div className="space-y-1.5">
                        {topic.checklist.map((item, idx) => {
                          const isChecked = checkedItems[`${topic.id}-${idx}`];
                          return (
                            <div
                              key={idx}
                              onClick={() => toggleCheck(topic.id, idx)}
                              className="flex items-start gap-2.5 cursor-pointer hover:bg-zinc-50 p-1.5 rounded transition-colors text-xs font-medium text-zinc-700"
                            >
                              {isChecked ? (
                                <CheckSquare className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                              ) : (
                                <Square className="h-4 w-4 text-zinc-300 shrink-0 mt-0.5" />
                              )}
                              <span className={isChecked ? 'line-through text-zinc-400' : ''}>{item}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              {!isExpanded && (
                <button
                  onClick={() => setExpandedId(topic.id)}
                  className="mt-4 pt-3 border-t border-zinc-100 text-[10px] font-bold text-zinc-900 hover:underline text-left flex items-center justify-between"
                >
                  Espandi adempimenti e consulenza →
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
