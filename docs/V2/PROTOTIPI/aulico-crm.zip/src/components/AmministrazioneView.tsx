/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Societa, FlussoMese, CollaboratoreIncentivo } from '../types';
import {
  FileSpreadsheet,
  TrendingUp,
  CreditCard,
  Plus,
  ArrowUpRight,
  DollarSign,
  Award,
  ChevronRight,
  Database,
  BarChart2,
  LineChart as LineIcon,
  CheckCircle,
  HelpCircle,
  Lock,
  Eye
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line
} from 'recharts';

interface AmministrazioneViewProps {
  financeData: { [key in Societa]: FlussoMese[] };
  collaboratoriIncentivo: CollaboratoreIncentivo[];
  activeSocieta: Societa;
  onUpdateFinanceData: (societa: Societa, data: FlussoMese[]) => void;
}

export default function AmministrazioneView({
  financeData,
  collaboratoriIncentivo,
  activeSocieta,
  onUpdateFinanceData
}: AmministrazioneViewProps) {
  // Current selected tab: 'piano_finanziario', 'programmazione_fatturazione', 'erogato'
  const [tab, setTab] = useState<'piano_finanziario' | 'programmazione_fatturazione' | 'erogato'>('piano_finanziario');
  
  // Select collaborator in erogato tab
  const [selectedCollaboratore, setSelectedCollaboratore] = useState<string>('Vitania Rubino');

  // Load finance data of the active company
  const activeCompanyFlows = financeData[activeSocieta] || [];

  // Handle cell edit in the Piano Finanziario table
  const handleCellChange = (index: number, field: keyof FlussoMese, value: string) => {
    const parsedValue = Number(value.replace(/[^0-9.-]+/g, '')) || 0;
    const updatedFlows = [...activeCompanyFlows];
    updatedFlows[index] = {
      ...updatedFlows[index],
      [field]: parsedValue
    };
    onUpdateFinanceData(activeSocieta, updatedFlows);
  };

  // Calculated totals of the Piano Finanziario
  const totalPreventivato = activeCompanyFlows.reduce((sum, item) => sum + item.preventivato, 0);
  const totalVenduto = activeCompanyFlows.reduce((sum, item) => sum + item.venduto, 0);
  const totalFatturato = activeCompanyFlows.reduce((sum, item) => sum + item.fatturato, 0);
  const totalIncassato = activeCompanyFlows.reduce((sum, item) => sum + item.incassato, 0);
  const totalCostiFissi = activeCompanyFlows.reduce((sum, item) => sum + item.costiFissi, 0);
  const totalCostiVariabili = activeCompanyFlows.reduce((sum, item) => sum + item.costiVariabili, 0);
  const totalCosti = totalCostiFissi + totalCostiVariabili;
  const totalUtileLordo = totalIncassato - totalCosti;

  // Selected collaborator statistics data
  const selectedCollabData = collaboratoriIncentivo.find((c) => c.nome === selectedCollaboratore);
  const chartData = selectedCollabData
    ? Object.keys(selectedCollabData.puntiMese).map((mese) => ({
        name: mese,
        Punti: selectedCollabData.puntiMese[mese],
        Premio: (selectedCollabData.puntiMese[mese] * 12.5).toFixed(2) // Mock incentive multiplier
      }))
    : [];

  // Monthly invoicing schedule entries mock
  const [fatturazioni, setFatturazioni] = useState([
    { id: 'f-1', cliente: 'SEIM S.R.L.', imponibile: 5950.0, stato: 'FATTURATO - Onirico Design', pagamento: 'CONTANTE', mese: 'GENNAIO' },
    { id: 'f-2', cliente: 'Vallegna Soc. Agr.', imponibile: 8873.74, stato: 'FATTURATO - Onirico Design', pagamento: 'INCASSATO', mese: 'GENNAIO' },
    { id: 'f-3', cliente: 'Turco Angela', imponibile: 5680.0, stato: 'FATTURATO - Onirico Design', pagamento: 'CONTANTE', mese: 'GENNAIO' },
    { id: 'f-4', cliente: 'Supple Denton', imponibile: 3300.0, stato: 'FATTURATO - Onirico Design', pagamento: 'INCASSATO', mese: 'GENNAIO' },
    { id: 'f-5', cliente: 'Colucci Aldo Mariano', imponibile: 2640.0, stato: 'FATTURATO - Onirico Design', pagamento: 'INCASSATO', mese: 'FEBBRAIO' },
    { id: 'f-6', cliente: 'Ricci Rocco', imponibile: 3760.0, stato: 'FATTURATO - Onirico Design', pagamento: 'CONTANTE', mese: 'FEBBRAIO' },
    { id: 'f-7', cliente: 'Velardi Maria', imponibile: 2100.0, stato: 'SPESE ANTICIPATE', pagamento: 'INCASSATO', mese: 'FEBBRAIO' },
    { id: 'f-8', cliente: 'Bichard James - Trullo', imponibile: 7516.67, stato: 'FATTURATO - Onirico Design', pagamento: 'INCASSATO', mese: 'MARZO' }
  ]);

  const handleUpdatePagamento = (id: string, newVal: string) => {
    setFatturazioni(fatturazioni.map((f) => (f.id === id ? { ...f, pagamento: newVal } : f)));
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50 overflow-hidden" id="amministrazione-module">
      
      {/* Sub-tabs selector */}
      <div className="bg-white border-b border-zinc-100 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-6">
          <button
            onClick={() => setTab('piano_finanziario')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              tab === 'piano_finanziario' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
            id="admin-sub-tab-piano"
          >
            Piano Finanziario Aziendale
          </button>
          <button
            onClick={() => setTab('programmazione_fatturazione')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              tab === 'programmazione_fatturazione' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
            id="admin-sub-tab-fatture"
          >
            Programmazione Fatturazione (Francesco)
          </button>
          <button
            onClick={() => setTab('erogato')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              tab === 'erogato' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
            id="admin-sub-tab-erogato"
          >
            Statistiche Erogato (Piano Incentivi)
          </button>
        </div>

        {/* Demo status note */}
        <span className="text-[10px] font-bold bg-amber-500/10 border border-amber-500/30 text-amber-600 px-2.5 py-1 rounded-full uppercase w-fit flex items-center gap-1">
          <CheckCircle className="h-3 w-3" /> Foglio Attivo ricalcolato
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {/* PIANO FINANZIARIO VIEW */}
        {tab === 'piano_finanziario' && (
          <div className="space-y-6" id="piano-finanziario-panel">
            
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Piano Finanziario Integrato ({activeSocieta})</h2>
                <p className="text-xs text-zinc-400 mt-0.5">Gestione di preventivi, fatturato, costi fissi e variabili per il controllo di liquidità.</p>
              </div>
            </div>

            {/* KPI Summary cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="kpi-cards">
              
              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs">
                <p className="text-[10px] font-bold text-zinc-400 uppercase">Preventivato Totale</p>
                <p className="text-xl font-black text-zinc-950 mt-1">{totalPreventivato.toLocaleString('it-IT')} €</p>
                <span className="text-[9px] text-zinc-400 mt-0.5 font-medium block">In corso di negoziazione</span>
              </div>

              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs">
                <p className="text-[10px] font-bold text-zinc-400 uppercase text-indigo-500">Fatturato Netto</p>
                <p className="text-xl font-black text-indigo-700 mt-1">{totalFatturato.toLocaleString('it-IT')} €</p>
                <span className="text-[9px] text-zinc-400 mt-0.5 font-medium block">Emesso a clienti</span>
              </div>

              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs">
                <p className="text-[10px] font-bold text-zinc-400 uppercase text-emerald-500">Incassato Reale</p>
                <p className="text-xl font-black text-emerald-700 mt-1">{totalIncassato.toLocaleString('it-IT')} €</p>
                <span className="text-[9px] text-zinc-400 mt-0.5 font-medium block">Disponibilità liquida accertata</span>
              </div>

              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs">
                <p className="text-[10px] font-bold text-zinc-400 uppercase text-red-500">Utile Previsto (Lordoliquidità)</p>
                <p className={`text-xl font-black mt-1 ${totalUtileLordo >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
                  {totalUtileLordo.toLocaleString('it-IT')} €
                </p>
                <span className="text-[9px] text-zinc-400 mt-0.5 font-medium block">Margine reale (Incassato - Costi)</span>
              </div>

            </div>

            {/* Editable Finance matrix (As spreadsheet) */}
            <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-xs">
              <div className="p-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
                <span className="text-xs font-bold text-zinc-800">MATRICE FINANZIARIA ATTIVA (Celle modificabili in tempo reale)</span>
                <span className="text-[10px] text-zinc-400 italic">I calcoli di utile e margine si aggiornano istantaneamente</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs" id="piano-edit-table">
                  <thead>
                    <tr className="bg-zinc-100 border-b border-zinc-200 text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
                      <th className="p-3">Mese</th>
                      <th className="p-3">Preventivato (€)</th>
                      <th className="p-3">Venduto (€)</th>
                      <th className="p-3 text-indigo-700">Fatturato (€)</th>
                      <th className="p-3 text-emerald-700">Incassato (€)</th>
                      <th className="p-3 text-red-600">Costi Fissi (€)</th>
                      <th className="p-3 text-red-600">Costi Var. (€)</th>
                      <th className="p-3 font-extrabold text-right">Margine Lordo (€)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-100 font-medium text-zinc-700">
                    {activeCompanyFlows.map((flow, index) => {
                      const lordoMese = flow.incassato - (flow.costiFissi + flow.costiVariabili);
                      return (
                        <tr key={index} className="hover:bg-zinc-50/50">
                          <td className="p-3 font-bold text-zinc-900 bg-zinc-50/30">{flow.mese}</td>
                          
                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.preventivato.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'preventivato', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-zinc-950 bg-transparent text-right font-semibold"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.venduto.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'venduto', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-zinc-950 bg-transparent text-right font-semibold"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.fatturato.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'fatturato', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-indigo-500 bg-indigo-50/30 text-right font-semibold text-indigo-700"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.incassato.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'incassato', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-emerald-500 bg-emerald-50/30 text-right font-semibold text-emerald-700"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.costiFissi.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'costiFissi', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-red-400 bg-transparent text-right font-semibold text-red-600"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={flow.costiVariabili.toLocaleString('it-IT')}
                              onChange={(e) => handleCellChange(index, 'costiVariabili', e.target.value)}
                              className="w-24 p-1.5 border border-zinc-100 rounded focus:border-red-400 bg-transparent text-right font-semibold text-red-600"
                            />
                          </td>

                          <td className={`p-3 text-right font-extrabold ${lordoMese >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
                            {lordoMese.toLocaleString('it-IT')} €
                          </td>
                        </tr>
                      );
                    })}

                    {/* Totals row */}
                    <tr className="bg-zinc-100 font-extrabold text-zinc-950 border-t-2 border-zinc-200">
                      <td className="p-3 uppercase">TOTALE</td>
                      <td className="p-3 text-right">{totalPreventivato.toLocaleString('it-IT')} €</td>
                      <td className="p-3 text-right">{totalVenduto.toLocaleString('it-IT')} €</td>
                      <td className="p-3 text-right text-indigo-700">{totalFatturato.toLocaleString('it-IT')} €</td>
                      <td className="p-3 text-right text-emerald-700">{totalIncassato.toLocaleString('it-IT')} €</td>
                      <td className="p-3 text-right text-red-600">{totalCostiFissi.toLocaleString('it-IT')} €</td>
                      <td className="p-3 text-right text-red-600">{totalCostiVariabili.toLocaleString('it-IT')} €</td>
                      <td className={`p-3 text-right text-sm ${totalUtileLordo >= 0 ? 'text-emerald-700 font-black' : 'text-red-700 font-black'}`}>
                        {totalUtileLordo.toLocaleString('it-IT')} €
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Cash flow projection chart using Recharts */}
            <div className="bg-white p-5 rounded-xl border border-zinc-200/60 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-zinc-900 uppercase tracking-wider">Grafico Flussi di Cassa Cumulati (6 Mesi)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={activeCompanyFlows} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="mese" tick={{ fontSize: 11, fontWeight: 'medium' }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="fatturato" fill="#4f46e5" name="Fatturato (€)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="incassato" fill="#10b981" name="Incassato (€)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="costiFissi" fill="#f43f5e" name="Costi (€)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>
        )}

        {/* PROGRAMMAZIONE FATTURAZIONE VIEW */}
        {tab === 'programmazione_fatturazione' && (
          <div className="space-y-6" id="programmazione-fatturazione-panel">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Programmazione Fatturazione Mensile (Francesco)</h2>
                <p className="text-xs text-zinc-400 mt-0.5">Controllo quotidiano delle emissioni, scadenze, imponibili e dei pagamenti in entrata.</p>
              </div>
              <button
                onClick={() => {
                  const client = prompt('Inserisci nome cliente per nuova fatturazione:');
                  if (!client) return;
                  const imp = prompt('Inserisci importo imponibile (€):');
                  if (!imp) return;
                  const newFatt = {
                    id: 'f-' + Date.now(),
                    cliente: client,
                    imponibile: Number(imp) || 0,
                    stato: 'FATTURATO - Onirico Design',
                    pagamento: 'CONTANTE',
                    mese: 'MAGGIO'
                  };
                  setFatturazioni([...fatturazioni, newFatt]);
                }}
                className="bg-zinc-950 text-white px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1 shadow-sm hover:bg-zinc-800"
              >
                + Aggiungi Voce Fatturazione
              </button>
            </div>

            <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs" id="fatturazioni-programmate-table">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                    <th className="p-4">Periodo / Mese</th>
                    <th className="p-4">Cliente / Ragione Sociale</th>
                    <th className="p-4">Imponibile</th>
                    <th className="p-4">Stato SDI</th>
                    <th className="p-4">Stato Pagamento</th>
                    <th className="p-4 text-right">Azioni</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 text-zinc-700 font-medium">
                  {fatturazioni.map((f) => (
                    <tr key={f.id} className="hover:bg-zinc-50/50">
                      <td className="p-4 font-bold text-zinc-900">{f.mese}</td>
                      <td className="p-4 font-semibold text-zinc-800">{f.cliente}</td>
                      <td className="p-4 font-bold text-zinc-950">{f.imponibile.toLocaleString('it-IT')} €</td>
                      <td className="p-4 text-zinc-500">{f.stato}</td>
                      <td className="p-4">
                        <select
                          value={f.pagamento}
                          onChange={(e) => handleUpdatePagamento(f.id, e.target.value)}
                          className={`p-1.5 border rounded text-[11px] font-bold ${
                            f.pagamento === 'INCASSATO' ? 'bg-emerald-50 text-emerald-800 border-emerald-100' :
                            f.pagamento === 'CONTANTE' ? 'bg-amber-50 text-amber-800 border-amber-100' :
                            'bg-red-50 text-red-800 border-red-100'
                          }`}
                        >
                          <option value="INCASSATO">INCASSATO</option>
                          <option value="CONTANTE">CONTANTE</option>
                          <option value="FATTURATO">FATTURATO</option>
                          <option value="STORNATO">STORNATO</option>
                        </select>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => setFatturazioni(fatturazioni.filter((item) => item.id !== f.id))}
                          className="text-red-500 hover:text-red-700 font-bold hover:underline"
                        >
                          Elimina
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* STATISTICHE EROGATO (INCENTIVI) VIEW */}
        {tab === 'erogato' && (
          <div className="space-y-6" id="erogato-performance-panel">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Piano Incentivante Collaboratori (Erogato)</h2>
                <p className="text-xs text-zinc-400 mt-0.5">Statistiche dei punti mensili erogati per premiare le prestazioni del team tecnico.</p>
              </div>

              {/* Collaborators selector list */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1" id="incentivi-collab-selector">
                {collaboratoriIncentivo.map((col) => (
                  <button
                    key={col.nome}
                    onClick={() => setSelectedCollaboratore(col.nome)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                      selectedCollaboratore === col.nome
                        ? 'bg-zinc-950 text-white shadow-sm'
                        : 'bg-white border border-zinc-200 text-zinc-500 hover:bg-zinc-100'
                    }`}
                  >
                    {col.nome}
                  </button>
                ))}
              </div>
            </div>

            {selectedCollabData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="collab-incentive-details">
                
                {/* Left metrics info */}
                <div className="bg-white p-5 rounded-xl border border-zinc-200/60 shadow-xs flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2.5 text-zinc-500">
                      <Award className="h-5 w-5 text-amber-500" />
                      <span className="text-xs font-extrabold uppercase tracking-wider text-zinc-900">Scheda Collaboratore</span>
                    </div>

                    <h3 className="text-lg font-extrabold text-zinc-950 mt-2">{selectedCollabData.nome}</h3>
                    <p className="text-xs text-zinc-400">Punti totalizzati nel piano incentivante del periodo in corso.</p>

                    <div className="border-t border-zinc-100 pt-3 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Totale Punti Maturati:</span>
                        <span className="font-extrabold text-zinc-950 font-mono">
                          {Object.values(selectedCollabData.puntiMese).reduce((a, b) => a + b, 0)} PUNTI
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Incentivo Lordo Maturato:</span>
                        <span className="font-extrabold text-emerald-600 font-mono">
                          {(Object.values(selectedCollabData.puntiMese).reduce((a, b) => a + b, 0) * 12.5).toLocaleString('it-IT')} €
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-100 mt-4">
                    <h4 className="text-[10px] font-bold text-zinc-500 uppercase">Valutazione Prestazione</h4>
                    <p className="text-xs font-semibold text-zinc-700 mt-1">Superamento obiettivi prefissati del 12% su base semestrale. Consigliato avanzamento livello.</p>
                  </div>
                </div>

                {/* Right Recharts points graph */}
                <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-zinc-200/60 shadow-xs space-y-4">
                  <h3 className="text-sm font-bold text-zinc-900 uppercase tracking-wider">Punti Maturati Mensili</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} />
                        <Tooltip />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Line type="monotone" dataKey="Punti" stroke="#3b82f6" strokeWidth={3} name="Punti Piano Incentivo" activeDot={{ r: 8 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
