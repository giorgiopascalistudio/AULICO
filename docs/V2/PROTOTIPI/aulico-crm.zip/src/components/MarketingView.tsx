/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Megaphone, Calendar, BarChart, Gift, FileText, Plus, CheckSquare } from 'lucide-react';

interface MarketingViewProps {
  gadgets: { id: string; nome: string; quantita: number; evento: string; consegnati: number }[];
  blogArticles: { id: string; titolo: string; stato: string; data: string; autore: string }[];
  onAddGadget: (g: any) => void;
  onAddBlogArticle: (a: any) => void;
}

export default function MarketingView({
  gadgets,
  blogArticles,
  onAddGadget,
  onAddBlogArticle
}: MarketingViewProps) {
  const [subTab, setSubTab] = useState<'editoriale' | 'gadget' | 'articoli' | 'eventi'>('editoriale');

  // New gadget form
  const [showGadgetForm, setShowGadgetForm] = useState(false);
  const [gNome, setGNome] = useState('');
  const [gQty, setGQty] = useState(100);
  const [gEvento, setGEvento] = useState('Natale 2026');

  const handleAddGadgetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gNome) return;
    onAddGadget({
      id: 'g-' + Date.now(),
      nome: gNome,
      quantita: gQty,
      evento: gEvento,
      consegnati: 0
    });
    setGNome('');
    setShowGadgetForm(false);
  };

  // New blog form
  const [showBlogForm, setShowBlogForm] = useState(false);
  const [bTitolo, setBTitolo] = useState('');
  const [bAutore, setBAutore] = useState('Rosa Custodero');

  const handleAddBlogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bTitolo) return;
    onAddBlogArticle({
      id: 'b-' + Date.now(),
      titolo: bTitolo,
      stato: 'In Redazione',
      data: new Date().toISOString().split('T')[0],
      autore: bAutore
    });
    setBTitolo('');
    setShowBlogForm(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50 overflow-hidden" id="marketing-module">
      {/* Sub tabs */}
      <div className="bg-white border-b border-zinc-100 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-6">
          <button
            onClick={() => setSubTab('editoriale')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              subTab === 'editoriale' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
          >
            Calendario Editoriale
          </button>
          <button
            onClick={() => setSubTab('gadget')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              subTab === 'gadget' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
          >
            Gadget & Regali (Natale)
          </button>
          <button
            onClick={() => setSubTab('articoli')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              subTab === 'articoli' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
          >
            Articoli del Blog
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {/* EDITORIAL CALENDAR */}
        {subTab === 'editoriale' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-zinc-950">Calendario Editoriale Social (Instagram & Facebook)</h3>
              <p className="text-xs text-zinc-400 mt-1">Pianificazione grafica mensile curata da Rosa Custodero per posizionare il brand Onirico.</p>
            </div>

            {/* Grid represent month days */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">POST INSTAGRAM</span>
                  <span className="text-[10px] text-zinc-400 font-mono">Lun 22 Giu</span>
                </div>
                <h4 className="text-xs font-bold text-zinc-900">Villa d'Itria: Avanzamento Cantiere</h4>
                <p className="text-xs text-zinc-500 leading-relaxed">Presentazione degli scavi piscina con pietra locale a secco e tonalità calde.</p>
                <div className="bg-zinc-100 p-2 rounded text-[10px] text-zinc-500 font-semibold border border-zinc-200/30 flex items-center gap-1">
                  📸 Foto: drone_scavi_ostuni.png
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">REEL INSTAGRAM</span>
                  <span className="text-[10px] text-zinc-400 font-mono">Mer 24 Giu</span>
                </div>
                <h4 className="text-xs font-bold text-zinc-900">Intervista a Mastro Antonio</h4>
                <p className="text-xs text-zinc-500 leading-relaxed">L'arte pugliese della posa dei muretti a secco nel cantiere Materico.</p>
                <div className="bg-red-50 text-red-600 p-2 rounded text-[10px] font-bold flex items-center gap-1.5 animate-pulse">
                  ⚠️ BLOCKED: Controllare Liberatoria Gioia M. prima del montaggio video!
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">NEWSLETTER</span>
                  <span className="text-[10px] text-zinc-400 font-mono">Ven 26 Giu</span>
                </div>
                <h4 className="text-xs font-bold text-zinc-900">Report per Investitori Esteri</h4>
                <p className="text-xs text-zinc-500 leading-relaxed">Analisi delle opportunità immobiliari e finanza agevolata in Puglia.</p>
                <div className="bg-zinc-100 p-2 rounded text-[10px] text-zinc-500 font-semibold border border-zinc-200/30 flex items-center gap-1">
                  📄 Doc: newsletter_giugno_lux.pdf
                </div>
              </div>
            </div>
          </div>
        )}

        {/* GADGET REGISTER */}
        {subTab === 'gadget' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-zinc-950">Registro Gadget, Omaggi e Pensieri</h3>
                <p className="text-xs text-zinc-400 mt-1">Storico dei regali fatti o ricevuti per Natale ed eventi strategici aziendali.</p>
              </div>
              <button
                onClick={() => setShowGadgetForm(true)}
                className="bg-zinc-950 text-white px-3 py-1.5 rounded text-xs font-semibold"
              >
                + Nuovo OMAGGIO / Pensiero
              </button>
            </div>

            <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase">
                    <th className="p-4">Articolo / Gadget</th>
                    <th className="p-4">Quantità Totale</th>
                    <th className="p-4">Campagna / Occasione</th>
                    <th className="p-4">Consegnati</th>
                    <th className="p-4 text-right">Rimanenza</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 font-medium text-zinc-700">
                  {gadgets.map((g) => (
                    <tr key={g.id}>
                      <td className="p-4 font-semibold text-zinc-900">{g.nome}</td>
                      <td className="p-4 font-mono font-bold">{g.quantita} pz</td>
                      <td className="p-4 text-zinc-500">{g.evento}</td>
                      <td className="p-4 font-bold text-emerald-600">{g.consegnati} pz</td>
                      <td className="p-4 text-right font-mono font-extrabold text-zinc-900">
                        {g.quantita - g.consegnati} pz
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Modal */}
            {showGadgetForm && (
              <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
                <div className="bg-white p-6 rounded-2xl shadow-xl w-full max-w-sm space-y-4">
                  <h4 className="font-bold text-sm">Registra Nuovo OMAGGIO</h4>
                  <form onSubmit={handleAddGadgetSubmit} className="space-y-3">
                    <input
                      type="text"
                      placeholder="Nome gadget (es. Borraccia alluminio)"
                      value={gNome}
                      onChange={(e) => setGNome(e.target.value)}
                      className="w-full p-2 border rounded text-xs"
                      required
                    />
                    <input
                      type="number"
                      placeholder="Quantità"
                      value={gQty}
                      onChange={(e) => setGQty(Number(e.target.value))}
                      className="w-full p-2 border rounded text-xs"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Occasione (es. Natale 2026)"
                      value={gEvento}
                      onChange={(e) => setGEvento(e.target.value)}
                      className="w-full p-2 border rounded text-xs"
                    />
                    <div className="flex justify-end gap-2">
                      <button type="button" onClick={() => setShowGadgetForm(false)} className="text-xs font-semibold text-zinc-500">Chiudi</button>
                      <button type="submit" className="bg-zinc-950 text-white text-xs px-3 py-1.5 rounded font-bold">Salva</button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ARTICLES */}
        {subTab === 'articoli' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-zinc-950">Articoli del Blog & SEO</h3>
                <p className="text-xs text-zinc-400 mt-1">Copywriting e testi asseverati per posizionamento organico dei siti del gruppo.</p>
              </div>
              <button
                onClick={() => setShowBlogForm(true)}
                className="bg-zinc-950 text-white px-3 py-1.5 rounded text-xs font-semibold"
              >
                + Scrivi Articolo
              </button>
            </div>

            <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase">
                    <th className="p-4">Titolo Articolo</th>
                    <th className="p-4">Autore</th>
                    <th className="p-4">Data di Creazione</th>
                    <th className="p-4">Stato Pubblicazione</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 font-medium text-zinc-700">
                  {blogArticles.map((art) => (
                    <tr key={art.id}>
                      <td className="p-4 font-semibold text-zinc-900">{art.titolo}</td>
                      <td className="p-4 text-zinc-500">{art.autore}</td>
                      <td className="p-4 font-mono">{art.data}</td>
                      <td className="p-4">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          art.stato === 'Pubblicato' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {art.stato}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Modal */}
            {showBlogForm && (
              <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
                <div className="bg-white p-6 rounded-2xl shadow-xl w-full max-w-sm space-y-4">
                  <h4 className="font-bold text-sm">Crea Articolo Blog</h4>
                  <form onSubmit={handleAddBlogSubmit} className="space-y-3">
                    <input
                      type="text"
                      placeholder="Titolo dell'articolo..."
                      value={bTitolo}
                      onChange={(e) => setBTitolo(e.target.value)}
                      className="w-full p-2 border rounded text-xs"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Autore (es. Rosa Custodero)"
                      value={bAutore}
                      onChange={(e) => setBAutore(e.target.value)}
                      className="w-full p-2 border rounded text-xs"
                    />
                    <div className="flex justify-end gap-2">
                      <button type="button" onClick={() => setShowBlogForm(false)} className="text-xs font-semibold text-zinc-500">Chiudi</button>
                      <button type="submit" className="bg-zinc-950 text-white text-xs px-3 py-1.5 rounded font-bold">Inizia Redazione</button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
