/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trash2, RotateCcw, AlertTriangle } from 'lucide-react';
import { Contact } from '../types';

interface CestinoViewProps {
  deletedContacts: Contact[];
  onRestoreContact: (contact: Contact) => void;
  onHardDeleteContact: (id: string) => void;
}

export default function CestinoView({
  deletedContacts,
  onRestoreContact,
  onHardDeleteContact
}: CestinoViewProps) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-zinc-50" id="cestino-module">
      
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold text-zinc-950 tracking-tight">Cestino di Ripristino (Recycling Bin)</h2>
        <p className="text-xs text-zinc-400 mt-1">Recupero immediato di contatti, file o preventivi eliminati accidentalmente per evitare perdite di dati di lavoro.</p>
      </div>

      {/* Content list */}
      {deletedContacts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-zinc-200/60 p-12 text-center space-y-3">
          <Trash2 className="h-12 w-12 text-zinc-300 mx-auto" />
          <h3 className="text-sm font-bold text-zinc-700">Il cestino è vuoto</h3>
          <p className="text-xs text-zinc-400 max-w-sm mx-auto">Tutti i dati aziendali e i contatti sono salvati in modo sicuro nel database di produzione.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-2xs">
          <div className="p-4 bg-zinc-50 border-b border-zinc-100 flex items-center justify-between text-xs font-bold text-red-700 shrink-0">
            <span className="flex items-center gap-1.5"><AlertTriangle className="h-4 w-4" /> Elementi nel Cestino</span>
            <span>Eliminazione automatica programmata tra 60 giorni</span>
          </div>

          <div className="divide-y divide-zinc-100" id="deleted-contacts-list">
            {deletedContacts.map((c) => (
              <div key={c.id} className="p-4 flex items-center justify-between gap-4 hover:bg-red-50/10 text-xs">
                
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-zinc-950">{c.name} {c.surname}</h4>
                  <div className="flex items-center gap-2 text-[10px] text-zinc-400 font-semibold uppercase">
                    <span>Categoria: {c.categoria}</span>
                    <span>•</span>
                    <span>Azienda: {c.companyName || 'Privato'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onRestoreContact(c);
                      alert(`Contatto ${c.name} ${c.surname} ripristinato con successo!`);
                    }}
                    className="bg-zinc-900 hover:bg-zinc-800 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1"
                    id={`btn-restore-${c.id}`}
                  >
                    <RotateCcw className="h-3.5 w-3.5" /> Ripristina
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Sei sicuro di voler eliminare DEFINITIVAMENTE ${c.name} ${c.surname}? L'operazione è irreversibile.`)) {
                        onHardDeleteContact(c.id);
                      }
                    }}
                    className="text-red-600 hover:text-red-800 hover:bg-red-50 px-3 py-1.5 rounded-lg font-semibold"
                  >
                    Elimina Definitivamente
                  </button>
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
