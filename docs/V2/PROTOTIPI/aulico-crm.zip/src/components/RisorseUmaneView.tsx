/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Briefcase, Folder, Users, FileText, CheckCircle, UserPlus, FileCheck } from 'lucide-react';

const HR_FOLDERS = [
  { code: '01', name: '01-Job description', desc: 'Template e requisiti dei ruoli cercati (PM, Geometri, Ingegneri).' },
  { code: '02', name: '02-Annunci', desc: 'Annunci di lavoro attivi su Indeed, LinkedIn e portali locali.' },
  { code: '03', name: '03-Candidati', desc: 'Raccolta CV e schede di valutazione d\'ingresso.' },
  { code: '04', name: '04-Colloqui', desc: 'Calendario e note dei colloqui conoscitivi effettuati.' },
  { code: '05', name: '05-Piano d\'inserimento', desc: 'Manuale d\'onboarding per le nuove risorse inserite.' },
  { code: '06', name: '06-Tirocini e stage', desc: 'Convenzioni con università e piani formativi in corso.' },
  { code: '07', name: '07-Collaboratori', desc: 'Contatti e anagrafica dei collaboratori tecnici attivi.' },
  { code: '08', name: '08-Ex collaboratori', desc: 'Archivio storico dei rapporti di collaborazione conclusi.' },
  { code: '09', name: '09-Corsi e procedure HR', desc: 'Attestati sicurezza e manuali operativi di studio.' },
  { code: '10', name: '10-Team building', desc: 'Organizzazione eventi, attività e cene di gruppo Aulico.' }
];

export default function RisorseUmaneView() {
  const [activeCode, setActiveCode] = useState('03'); // Default: Candidati

  const [candidates, setCandidates] = useState([
    { id: 1, nome: 'Giuseppe De Nitto', ruolo: 'Geometra di cantiere', voto: '8/10', stato: 'In attesa di secondo colloquio', cv: 'CV_DeNitto_Geom.pdf' },
    { id: 2, nome: 'Roberta Colella', ruolo: 'Interior Designer', voto: '9.5/10', stato: 'Proposta d\'assunzione inviata', cv: 'CV_Colella_Designer.pdf' },
    { id: 3, nome: 'Vito Saponaro', ruolo: 'Ingegnere Strutturista junior', voto: '7/10', stato: 'In graduatoria', cv: 'CV_Saponaro_Ing.pdf' }
  ]);

  const [newCandName, setNewCandName] = useState('');
  const [newCandRole, setNewCandRole] = useState('Geometra di cantiere');
  const [newCandScore, setNewCandScore] = useState('8/10');

  const handleAddCandidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCandName) return;
    setCandidates([
      ...candidates,
      {
        id: Date.now(),
        nome: newCandName,
        ruolo: newCandRole,
        voto: newCandScore,
        stato: 'Colloquio conoscitivo da programmare',
        cv: 'CV_Nuovo_Candidato.pdf'
      }
    ]);
    setNewCandName('');
  };

  const activeFolder = HR_FOLDERS.find((f) => f.code === activeCode);

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-full min-h-0 bg-zinc-50 overflow-hidden" id="risorse-umane-module">
      
      {/* LEFT AREA: HR Folders Directory navigation */}
      <div className="w-full lg:w-80 border-r border-zinc-200/60 bg-white flex flex-col h-full min-h-0">
        <div className="p-4 border-b border-zinc-100 shrink-0 flex items-center gap-2">
          <Briefcase className="h-5 w-5 text-zinc-950" />
          <h2 className="text-base font-bold text-zinc-950">Sezione Risorse Umane</h2>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-zinc-50" id="hr-folders-list">
          {HR_FOLDERS.map((folder) => {
            const isSelected = activeCode === folder.code;
            return (
              <button
                key={folder.code}
                onClick={() => setActiveCode(folder.code)}
                className={`w-full p-3.5 text-left transition-all flex items-start gap-3 ${
                  isSelected ? 'bg-zinc-100 text-zinc-950 font-bold border-l-4 border-zinc-950' : 'text-zinc-600 hover:bg-zinc-50/50'
                }`}
              >
                <Folder className={`h-4.5 w-4.5 shrink-0 mt-0.5 ${isSelected ? 'text-zinc-950' : 'text-zinc-400'}`} />
                <div className="min-w-0">
                  <p className="text-xs font-semibold truncate">{folder.name}</p>
                  <p className="text-[10px] text-zinc-400 truncate mt-0.5">{folder.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* RIGHT AREA: Expanded folder details */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 flex flex-col min-h-0">
        <div className="border-b border-zinc-100 pb-4 shrink-0">
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Dettaglio Sotto-sezione</span>
          <h3 className="text-lg font-bold text-zinc-950 mt-1">{activeFolder?.name}</h3>
          <p className="text-xs text-zinc-500 mt-0.5 font-medium">{activeFolder?.desc}</p>
        </div>

        {/* CANDIDATES DIRECTORY SPECIAL VIEW */}
        {activeCode === '03' && (
          <div className="space-y-6 flex-1 overflow-y-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Form to insert candidate */}
              <div className="bg-white p-5 rounded-xl border border-zinc-200/60 shadow-2xs space-y-4 h-fit">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-1.5">
                  <UserPlus className="h-4 w-4" /> Registra Candidato
                </h4>

                <form onSubmit={handleAddCandidate} className="space-y-3.5">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase">Nome e Cognome *</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border rounded text-xs bg-zinc-50"
                      value={newCandName}
                      onChange={(e) => setNewCandName(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase">Mansione / Ruolo</label>
                    <select
                      className="w-full mt-1 p-2 border rounded text-xs bg-zinc-50"
                      value={newCandRole}
                      onChange={(e) => setNewCandRole(e.target.value)}
                    >
                      <option value="Geometra di cantiere">Geometra di cantiere</option>
                      <option value="Interior Designer">Interior Designer</option>
                      <option value="Ingegnere Strutturista junior">Ingegnere Strutturista junior</option>
                      <option value="Disegnatore CAD 3D">Disegnatore CAD 3D</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase">Valutazione / Voto</label>
                    <select
                      className="w-full mt-1 p-2 border rounded text-xs bg-zinc-50"
                      value={newCandScore}
                      onChange={(e) => setNewCandScore(e.target.value)}
                    >
                      <option value="10/10">10/10 (Eccellente)</option>
                      <option value="9/10">9/10 (Ottimo)</option>
                      <option value="8/10">8/10 (Buono)</option>
                      <option value="7/10">7/10 (Sufficiente)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-zinc-950 text-white text-xs font-bold py-2 rounded-lg"
                  >
                    Inserisci in Archivio
                  </button>
                </form>
              </div>

              {/* List of active candidates */}
              <div className="lg:col-span-2 space-y-3">
                <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">Candidati in attesa di selezione</h4>
                <div className="space-y-3" id="candidates-cards-list">
                  {candidates.map((cand) => (
                    <div key={cand.id} className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h5 className="text-sm font-bold text-zinc-950">{cand.nome}</h5>
                          <span className="bg-zinc-100 text-zinc-600 text-[9px] font-bold px-1.5 py-0.2 rounded">
                            Voto: {cand.voto}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-500 font-semibold">{cand.ruolo}</p>
                        <p className="text-[10px] text-zinc-400">Stato: <strong className="text-zinc-600">{cand.stato}</strong></p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] bg-zinc-100 text-zinc-600 px-2.5 py-1 rounded-lg font-mono">
                          📎 {cand.cv}
                        </span>
                        <button
                          onClick={() => alert(`Apertura file CV di ${cand.nome}`)}
                          className="bg-zinc-900 hover:bg-zinc-800 text-white px-2.5 py-1.5 rounded text-[10px] font-bold"
                        >
                          Vedi CV
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* OTHER HR FILES MOCK TABLE */}
        {activeCode !== '03' && (
          <div className="bg-white rounded-xl border border-zinc-200/60 p-6 shadow-2xs text-center space-y-3">
            <FileText className="h-10 w-10 text-zinc-400 mx-auto" />
            <h4 className="text-sm font-bold text-zinc-900">Cartella Digitale Abilitata</h4>
            <p className="text-xs text-zinc-500 max-w-md mx-auto">
              Contiene i documenti normativi del gruppo Aulico relativi a <strong>{activeFolder?.name}</strong>. Puoi inserire file o procedere con l'onboarding integrato.
            </p>
            <div className="pt-2">
              <button
                onClick={() => alert('Funzione di caricamento documenti HR abilitata.')}
                className="bg-zinc-950 text-white text-xs font-semibold px-4 py-2 rounded-lg"
              >
                + Aggiungi File a {activeFolder?.name.split('-')[1]}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
