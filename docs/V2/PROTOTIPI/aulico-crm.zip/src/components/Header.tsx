/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Societa } from '../types';
import { Search, Bell, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeSocieta: Societa;
  onSocietaChange: (societa: Societa) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeRole: string;
  onRoleChange: (role: string) => void;
}

export const SOCIETA_LABELS: { [key in Societa]: string } = {
  [Societa.STRATEGICO]: 'strategico',
  [Societa.UNICO]: 'unico',
  [Societa.ONIRICO]: 'onirico',
  [Societa.MATERICO]: 'materico',
  [Societa.FANTASTICO]: 'fantastico'
};

export const SOCIETA_THEME: { [key in Societa]: { bg: string; text: string; border: string; accent: string; font: string } } = {
  [Societa.STRATEGICO]: {
    bg: 'bg-indigo-50 text-indigo-700',
    text: 'text-indigo-900',
    border: 'border-indigo-200',
    accent: 'indigo',
    font: 'font-sans font-extrabold tracking-wider'
  },
  [Societa.UNICO]: {
    bg: 'bg-amber-50 text-amber-700',
    text: 'text-amber-900',
    border: 'border-amber-200',
    accent: 'amber',
    font: 'font-serif italic font-bold'
  },
  [Societa.ONIRICO]: {
    bg: 'bg-zinc-900 text-white',
    text: 'text-zinc-950',
    border: 'border-zinc-800',
    accent: 'zinc',
    font: 'font-sans font-light tracking-widest lowercase'
  },
  [Societa.MATERICO]: {
    bg: 'bg-stone-100 text-stone-700',
    text: 'text-stone-900',
    border: 'border-stone-300',
    accent: 'stone',
    font: 'font-mono font-semibold uppercase'
  },
  [Societa.FANTASTICO]: {
    bg: 'bg-emerald-50 text-emerald-700',
    text: 'text-emerald-900',
    border: 'border-emerald-200',
    accent: 'emerald',
    font: 'font-sans tracking-tight font-black uppercase'
  }
};

export default function Header({
  activeSocieta,
  onSocietaChange,
  searchQuery,
  onSearchChange,
  activeRole,
  onRoleChange
}: HeaderProps) {
  const orderedSocieta = [
    Societa.STRATEGICO,
    Societa.UNICO,
    Societa.ONIRICO,
    Societa.MATERICO,
    Societa.FANTASTICO
  ];

  return (
    <header className="flex flex-col md:flex-row items-center justify-between border-b border-zinc-100 bg-white px-6 py-4 gap-4" id="aulico-header">
      {/* Company selection top pill */}
      <div className="flex flex-wrap items-center gap-1.5 bg-zinc-100 p-1 rounded-full text-xs font-medium" id="company-pill-selector">
        {orderedSocieta.map((soc) => {
          const isActive = activeSocieta === soc;
          return (
            <button
              key={soc}
              onClick={() => onSocietaChange(soc)}
              className={`px-3.5 py-1.5 rounded-full uppercase transition-all duration-300 ${
                isActive
                  ? 'bg-zinc-950 text-white shadow-sm scale-105'
                  : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-200'
              }`}
              id={`btn-soc-${soc.toLowerCase()}`}
            >
              {soc}
            </button>
          );
        })}
      </div>

      {/* Center Search and Interactive Role Switcher */}
      <div className="flex items-center gap-4 w-full md:w-auto justify-end">
        <div className="relative w-full max-w-xs" id="search-container">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Cerca contatti, preventivi..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-zinc-900 focus:border-transparent transition-all"
            id="global-search-input"
          />
        </div>

        {/* Dynamic Role Selector for Demo Experience */}
        <div className="flex items-center gap-2 border border-zinc-200 rounded-lg px-2 py-1 bg-zinc-50" id="role-selector-container">
          <Sparkles className="h-4 w-4 text-amber-500" />
          <select
            value={activeRole}
            onChange={(e) => onRoleChange(e.target.value)}
            className="text-xs bg-transparent border-none focus:ring-0 font-medium text-zinc-700 cursor-pointer"
            id="role-select"
          >
            <option value="Dario Fiore">PM: Dario Fiore</option>
            <option value="Francesco Zurlo">Fatture: Francesco Zurlo</option>
            <option value="Davide Ciracì">Pianificatore: Davide Ciracì</option>
            <option value="Rosa Custodero">Marketing: Rosa Custodero</option>
          </select>
        </div>

        {/* Notifications */}
        <button className="p-2 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 rounded-full relative" id="btn-notifications">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white"></span>
        </button>

        {/* Highlighted active company logo */}
        <div className="hidden lg:flex flex-col items-end pl-4 border-l border-zinc-200" id="brand-logo-panel">
          <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-widest">SOCIETÀ ATTIVA</span>
          <h1 className={`text-2xl leading-none capitalize ${SOCIETA_THEME[activeSocieta].font} text-zinc-950 mt-0.5`}>
            {SOCIETA_LABELS[activeSocieta]}
          </h1>
        </div>
      </div>
    </header>
  );
}
