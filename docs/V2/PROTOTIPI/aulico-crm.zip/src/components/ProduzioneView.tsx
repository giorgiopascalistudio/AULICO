/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Contact, DocumentoCliente, AttivitaTecnico } from '../types';
import {
  MapPin,
  Folder,
  Lock,
  Unlock,
  AlertOctagon,
  ChevronRight,
  Download,
  CheckCircle,
  Clock,
  Briefcase,
  Layers,
  FileSpreadsheet,
  FileCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ProduzioneViewProps {
  contacts: Contact[];
  documents: DocumentoCliente[];
  attivita: AttivitaTecnico[];
  onAddDocument: (doc: DocumentoCliente) => void;
  activeRole: string;
}

// Stages of construction folders
const DIRECTORY_FOLDERS = [
  { code: '00', name: '00-Presentazioni', sensibile: false },
  { code: '01', name: '01-Inquadramento', sensibile: false },
  { code: '02', name: '02-Rilievi', sensibile: false },
  { code: '03', name: '03-Progetti', sensibile: false },
  { code: '04', name: '04-Pratiche', sensibile: true },
  { code: '05', name: '05-Contabilità di cantiere', sensibile: true },
  { code: '06', name: '06-Direzione lavori', sensibile: false },
  { code: '07', name: '07-Sicurezza', sensibile: false },
  { code: '08', name: '08-Collaudo', sensibile: true },
  { code: '09', name: '09-Accatastamento', sensibile: true },
  { code: '10', name: '10-Autorizzazione agli scarichi', sensibile: true },
  { code: '12', name: '12-Agibilità', sensibile: true }, // HIGHLY SENSITIVE BLOCKED FOR MOROSI!
  { code: '13', name: '13-APE', sensibile: false },
  { code: '14', name: '14-CDU', sensibile: false },
  { code: '15', name: '15-ENEA', sensibile: false }
];

export default function ProduzioneView({
  contacts,
  documents,
  attivita,
  onAddDocument,
  activeRole
}: ProduzioneViewProps) {
  // Select active client in production view. Default to Gioia Mariagrazia
  const productionClients = contacts.filter((c) => c.categoria === 'Clienti' || c.id === 'gioia-mariagrazia');
  const [selectedClientId, setSelectedClientId] = useState<string>(productionClients[0]?.id || 'gioia-mariagrazia');
  const activeClient = contacts.find((c) => c.id === selectedClientId) || productionClients[0];

  // Active folder view inside client directory
  const [activeFolderCode, setActiveFolderCode] = useState<string>('00');
  const [showSueCompiler, setShowSueCompiler] = useState(false);
  const [sueDocType, setSueDocType] = useState('CILA');
  const [isCompiling, setIsCompiling] = useState(false);

  // Countdown timer for "LE SCELTE DEL COMMITTENTE" 60 days countdown (Page 9)
  const [countdown, setCountdown] = useState({ gg: 42, ore: 14, min: 22, sec: 10 });

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev.sec > 0) return { ...prev, sec: prev.sec - 1 };
        if (prev.min > 0) return { ...prev, min: prev.min - 1, sec: 59 };
        if (prev.ore > 0) return { ...prev, ore: prev.ore - 1, min: 59, sec: 59 };
        if (prev.gg > 0) return { ...prev, gg: prev.gg - 1, ore: 23, min: 59, sec: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const activeFolder = DIRECTORY_FOLDERS.find((f) => f.code === activeFolderCode);
  const folderDocuments = documents.filter((d) => d.categoria.startsWith(activeFolderCode));

  // Determine if active folder is blocked for this client
  const isFolderBlocked = activeClient && !activeClient.regolaritaPagamenti && activeFolder?.sensibile;

  // Handle document upload
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const handleUploadMock = () => {
    if (!activeClient) return;
    setUploadingDoc(true);
    setTimeout(() => {
      const newDoc: DocumentoCliente = {
        id: 'doc-' + Date.now(),
        nome: `${activeFolderCode}_Documento_Caricato_${Date.now().toString().slice(-4)}.pdf`,
        categoria: activeFolder?.name || '00-Presentazioni',
        sensibile: activeFolder?.sensibile || false,
        dataCaricamento: new Date().toISOString().replace('T', ' ').slice(0, 16),
        tipo: 'PDF',
        size: '1.8 MB'
      };
      onAddDocument(newDoc);
      setUploadingDoc(false);
      alert('Documento caricato con successo nella cartella ' + activeFolder?.name);
    }, 1200);
  };

  // Simulating the compilation of modular building permits (CILA, SCIA, etc.) Page 11
  const handleCompileSUE = () => {
    setIsCompiling(true);
    setTimeout(() => {
      setIsCompiling(false);
      setShowSueCompiler(false);
      // Auto add compiled document to Practices "04-Pratiche" folder!
      const compiledDoc: DocumentoCliente = {
        id: 'doc-' + Date.now(),
        nome: `Modulistica_SUE_${sueDocType}_Firmata_Tecnico.pdf`,
        categoria: '04-Pratiche',
        sensibile: true,
        dataCaricamento: new Date().toISOString().replace('T', ' ').slice(0, 16),
        tipo: 'PDF',
        size: '1.2 MB'
      };
      onAddDocument(compiledDoc);
      alert(`Pratica ${sueDocType} compilata correttamente e inserita in 04-Pratiche!`);
    }, 2000);
  };

  return (
    <div className="flex-1 flex flex-col xl:flex-row h-full min-h-0 bg-zinc-50 overflow-hidden" id="produzione-module">
      
      {/* LEFT CONTENT AREA: Map, Phases, SUE Compiler */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 flex flex-col min-h-0">
        
        {/* Selection bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-zinc-200/60 shadow-xs">
          <div>
            <h2 className="text-base font-bold text-zinc-950">Seleziona Cantiere / Cliente Attivo</h2>
            <p className="text-xs text-zinc-400 mt-0.5">Vedi lo stato delle pratiche, rilievi, contabilità e documenti sensibili.</p>
          </div>
          <select
            value={selectedClientId}
            onChange={(e) => setSelectedClientId(e.target.value)}
            className="p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50 focus:outline-none"
            id="produzione-client-select"
          >
            {productionClients.map((c) => (
              <option key={c.id} value={c.id}>{c.name} {c.surname} - {c.indirizzo}</option>
            ))}
          </select>
        </div>

        {activeClient ? (
          <>
            {/* ACTIVE SITES VECTOR MAP OVERVIEW (Perfect replica of Page 4 mockup) */}
            <div className="bg-zinc-950 text-white rounded-2xl border border-zinc-800 p-6 relative overflow-hidden shadow-lg h-60 flex flex-col justify-between" id="active-cantiere-map-container">
              {/* Decorative Tech UI Map Grid */}
              <div className="absolute inset-0 opacity-15 pointer-events-none" id="tech-grid-map">
                <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                  {/* Fake street roads paths */}
                  <path d="M 50,50 Q 200,80 400,60 T 800,140" fill="none" stroke="white" strokeWidth="3" />
                  <path d="M 120,0 Q 220,180 320,300 T 520,400" fill="none" stroke="white" strokeWidth="2.5" />
                  <path d="M 0,220 Q 300,240 600,180 T 1000,320" fill="none" stroke="white" strokeWidth="2" />
                </svg>
              </div>

              {/* Glowing Interactive Map Markers */}
              <div className="absolute top-[30%] left-[20%] group cursor-pointer" title="Cantiere Vado Aperto - Ostuni">
                <div className="h-4 w-4 bg-cyan-400 rounded-full animate-ping absolute"></div>
                <div className="h-4 w-4 bg-cyan-500 rounded-full border-2 border-white relative flex items-center justify-center">
                  <MapPin className="h-2 w-2 text-white" />
                </div>
                <span className="absolute left-6 -top-2 bg-zinc-900 border border-zinc-800 text-[9px] font-bold px-2 py-0.5 rounded whitespace-nowrap shadow-md text-cyan-400">Ostuni (Villa con Piscina)</span>
              </div>

              <div className="absolute top-[65%] left-[55%] group cursor-pointer" title="Cantiere Ceglie Messapica">
                <div className="h-3 w-3 bg-emerald-400 rounded-full animate-ping absolute"></div>
                <div className="h-3 w-3 bg-emerald-500 rounded-full border border-white relative"></div>
                <span className="absolute left-5 -top-2 bg-zinc-900 border border-zinc-800 text-[9px] font-bold px-2 py-0.5 rounded whitespace-nowrap shadow-md text-emerald-400">Ceglie Messapica</span>
              </div>

              <div className="absolute top-[45%] left-[80%] group cursor-pointer" title="Cantiere San Vito dei Normanni">
                <div className="h-3 w-3 bg-indigo-400 rounded-full animate-ping absolute"></div>
                <div className="h-3 w-3 bg-indigo-500 rounded-full border border-white relative"></div>
                <span className="absolute left-5 -top-2 bg-zinc-900 border border-zinc-800 text-[9px] font-bold px-2 py-0.5 rounded whitespace-nowrap shadow-md text-indigo-400">San Vito dei Normanni</span>
              </div>

              <div className="flex items-center justify-between shrink-0 relative z-10">
                <span className="text-[10px] font-bold tracking-widest text-zinc-500 uppercase">Mappa Cantieri Attivi</span>
                <span className="text-[10px] font-bold bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 px-2 py-0.5 rounded-full uppercase">
                  Coordinate GPS Esatte Attive
                </span>
              </div>

              <div className="relative z-10 max-w-sm">
                <h3 className="text-lg font-bold text-white leading-tight">Progetto: {activeClient.name} {activeClient.surname}</h3>
                <p className="text-xs text-zinc-400 font-medium mt-1">
                  Ubicazione: {activeClient.indirizzo}. Team: Turco Claudia, Pascali Giorgio, Argentiero Mino.
                </p>
              </div>

              <div className="relative z-10 flex items-center justify-between border-t border-zinc-800 pt-3 text-[10px] text-zinc-500 shrink-0 font-medium">
                <span>Rete logistica integrata subappalti</span>
                <span>Ostuni - Valle d'Itria Hub</span>
              </div>
            </div>

            {/* COUNTDOWN TIMER FOR CLIENT CHOICE (Page 9) */}
            <div className="bg-amber-500 text-zinc-950 p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 shrink-0 shadow-sm" id="client-choices-countdown">
              <div className="flex items-center gap-3">
                <Clock className="h-6 w-6 text-zinc-900 animate-pulse" />
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider">Scelte del Committente (Countdown 60 Giorni)</h4>
                  <p className="text-xs text-zinc-900 font-medium">Finiture, impianti e arredi fissi da confermare in contabilità prima del blocco.</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-zinc-950 font-mono font-bold" id="countdown-nums">
                <div className="bg-zinc-950 text-white rounded px-2.5 py-1.5 text-sm flex flex-col items-center">
                  <span>{countdown.gg}</span>
                  <span className="text-[8px] text-zinc-400 font-sans uppercase">GIORNI</span>
                </div>
                <span>:</span>
                <div className="bg-zinc-950 text-white rounded px-2.5 py-1.5 text-sm flex flex-col items-center">
                  <span>{countdown.ore}</span>
                  <span className="text-[8px] text-zinc-400 font-sans uppercase">ORE</span>
                </div>
                <span>:</span>
                <div className="bg-zinc-950 text-white rounded px-2.5 py-1.5 text-sm flex flex-col items-center">
                  <span>{countdown.min}</span>
                  <span className="text-[8px] text-zinc-400 font-sans uppercase">MIN</span>
                </div>
                <span>:</span>
                <div className="bg-zinc-950 text-white rounded px-2 rounded-t py-1.5 text-sm flex flex-col items-center bg-zinc-900">
                  <span>{countdown.sec}</span>
                  <span className="text-[8px] text-zinc-400 font-sans uppercase">SEC</span>
                </div>
              </div>
            </div>

            {/* DYNAMIC SUE MODULISTICA COMPILER CARD (Page 11) */}
            <div className="bg-zinc-900 text-white p-5 rounded-2xl border border-zinc-800 flex items-center justify-between shadow-md" id="sue-suap-widget">
              <div className="flex items-center gap-4">
                <div className="h-11 w-11 rounded-xl bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-300">
                  <Layers className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold">Compilatore Modulistica Edilizia — SUE/SUAP</h4>
                  <p className="text-xs text-zinc-500 mt-0.5">Compila e genera CILA, SCIA, permessi di costruire ed altra modulistica.</p>
                </div>
              </div>
              <button
                onClick={() => setShowSueCompiler(true)}
                className="bg-white hover:bg-zinc-200 text-zinc-950 px-4 py-2 rounded-xl text-xs font-bold transition-all"
                id="btn-open-sue"
              >
                Apri Compilatore →
              </button>
            </div>

            {/* 4 PRODUCTION PHASES FLOWS */}
            <div className="space-y-4" id="production-phases-overview">
              <h3 className="font-bold text-xs text-zinc-400 uppercase tracking-widest">Fasi e Processo Produttivo</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4" id="phases-grid">
                
                {/* 1. PIANIFICAZIONE */}
                <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-xs">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2 mb-2">
                    <span className="text-[10px] font-black uppercase text-indigo-600">Pianificazione</span>
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                  </div>
                  <ul className="text-[11px] text-zinc-500 space-y-1 font-medium list-disc pl-3">
                    <li>Analisi Urbanistica</li>
                    <li>Studio di Fattibilità</li>
                    <li>Moodboard materiali</li>
                    <li>Sopralluogo drone</li>
                  </ul>
                </div>

                {/* 2. PROGETTUALE */}
                <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-xs">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2 mb-2">
                    <span className="text-[10px] font-black uppercase text-amber-600">Progettuale</span>
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                  </div>
                  <ul className="text-[11px] text-zinc-500 space-y-1 font-medium list-disc pl-3">
                    <li>Rilievi 3D (Matterport)</li>
                    <li>Progetto Architettonico</li>
                    <li>Progetto Energetico</li>
                    <li>Computo Metrico</li>
                  </ul>
                </div>

                {/* 3. ABILITATIVA */}
                <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-xs">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2 mb-2">
                    <span className="text-[10px] font-black uppercase text-emerald-600">Abilitativa</span>
                    <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                  </div>
                  <ul className="text-[11px] text-zinc-500 space-y-1 font-medium list-disc pl-3">
                    <li>Pratica CILA Comune</li>
                    <li>Nullaosta Paesaggistico</li>
                    <li className="text-zinc-900 font-bold">Certificato Agibilità</li>
                    <li>Accatastamento</li>
                  </ul>
                </div>

                {/* 4. ESECUTIVA */}
                <div className="bg-white p-4 rounded-xl border border-zinc-200/60 shadow-xs">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2 mb-2">
                    <span className="text-[10px] font-black uppercase text-zinc-400">Esecutiva</span>
                    <Clock className="h-3.5 w-3.5 text-zinc-300" />
                  </div>
                  <ul className="text-[11px] text-zinc-300 space-y-1 font-medium list-disc pl-3">
                    <li>Direzione Lavori</li>
                    <li>Sicurezza CSE</li>
                    <li>Contabilità Cantiere</li>
                    <li>Consegna Chiavi</li>
                  </ul>
                </div>

              </div>
            </div>
          </>
        ) : (
          <p className="text-center text-zinc-400 py-12">Nessun cliente attivo in produzione.</p>
        )}
      </div>

      {/* RIGHT SIDEBAR: Folders and sensitive file list with blocking rule */}
      <div className="w-full xl:w-96 border-t xl:border-t-0 xl:border-l border-zinc-200/60 bg-white flex flex-col h-full min-h-0 shrink-0">
        
        {/* Header client info */}
        <div className="p-5 border-b border-zinc-100 bg-zinc-50/50 shrink-0">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-widest">CARTELLA CLIENTE</span>
            
            {/* Payment visual light */}
            {activeClient?.regolaritaPagamenti ? (
              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-100">
                ● REGOLARE
              </span>
            ) : (
              <span className="bg-red-50 text-red-700 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border border-red-100 animate-pulse">
                🔴 IRREGOLARE NEI PAGAMENTI
              </span>
            )}
          </div>

          <h3 className="font-bold text-sm text-zinc-900">{activeClient?.name} {activeClient?.surname}</h3>
          <p className="text-xs text-zinc-400 font-mono mt-0.5">Codice: ARC-2026-083</p>
        </div>

        {/* Directory Explorer layout */}
        <div className="flex-1 flex min-h-0">
          
          {/* Subfolders navigation list */}
          <div className="w-2/5 border-r border-zinc-100 overflow-y-auto" id="subfolders-list">
            {DIRECTORY_FOLDERS.map((f) => {
              const isSelected = activeFolderCode === f.code;
              return (
                <button
                  key={f.code}
                  onClick={() => setActiveFolderCode(f.code)}
                  className={`w-full p-3 text-left flex items-center justify-between border-b border-zinc-50/50 transition-colors ${
                    isSelected ? 'bg-zinc-100 font-bold text-zinc-950' : 'text-zinc-600 hover:bg-zinc-50'
                  }`}
                  id={`folder-btn-${f.code}`}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <Folder className={`h-4 w-4 shrink-0 ${isSelected ? 'text-zinc-950' : 'text-zinc-400'}`} />
                    <span className="text-[10px] truncate">{f.name.split('-')[1]}</span>
                  </div>
                  {f.sensibile && (
                    <Lock className="h-3 w-3 text-red-400 shrink-0 ml-1" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Files List Inside selected Folder */}
          <div className="flex-1 flex flex-col h-full min-h-0 bg-zinc-50/30 p-4" id="folder-files-vault">
            
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-zinc-100 shrink-0">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Documenti in cartella</span>
              
              {/* Upload mock file button */}
              <button
                onClick={handleUploadMock}
                disabled={uploadingDoc}
                className="text-[10px] font-extrabold bg-zinc-900 hover:bg-zinc-800 text-white px-2 py-1 rounded disabled:bg-zinc-400 transition-colors"
                id="btn-upload-file"
              >
                {uploadingDoc ? 'Caricamento...' : '+ Carica'}
              </button>
            </div>

            {/* BLOCKING VIEW FOR MOROSI IF SENSITIVE FOLDER */}
            {isFolderBlocked ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-red-50 rounded-xl border border-red-200/60" id="blocked-download-vault-alert">
                <AlertOctagon className="h-10 w-10 text-red-500 animate-bounce" />
                <h4 className="text-xs font-black text-red-700 uppercase mt-3 tracking-wider">📥 DOWNLOAD BLOCCATO</h4>
                <p className="text-[10px] text-red-600 mt-2 leading-relaxed">
                  I documenti relativi a questa pratica sensibile sono bloccati a causa di <strong>morosità o insoluti in contabilità</strong>.
                </p>
                <p className="text-[10px] text-zinc-500 italic mt-3 bg-white p-2 rounded border border-red-200/20 shadow-xs">
                  Regolarizzare la posizione con l'amministrativo <strong>Francesco Zurlo</strong> per sbloccare lo scaricamento di Agibilità o SCIA.
                </p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto space-y-2" id="files-list">
                {folderDocuments.length === 0 ? (
                  <p className="text-[10px] text-zinc-400 italic text-center py-8">Nessun file presente.</p>
                ) : (
                  folderDocuments.map((doc) => (
                    <div key={doc.id} className="p-3 bg-white rounded-lg border border-zinc-200/50 space-y-2 shadow-2xs" id={`doc-item-${doc.id}`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-[11px] font-semibold text-zinc-800 truncate" title={doc.nome}>{doc.nome}</p>
                          <p className="text-[9px] text-zinc-400 mt-0.5 font-mono">{doc.dataCaricamento} • {doc.size}</p>
                        </div>
                        {doc.sensibile && <Unlock className="h-3 w-3 text-emerald-400 shrink-0 mt-0.5" title="Sbloccato per download" />}
                      </div>

                      <div className="flex items-center justify-between border-t border-zinc-100 pt-2 shrink-0">
                        <span className="text-[9px] text-zinc-500 font-mono uppercase bg-zinc-100 px-1.5 py-0.5 rounded">{doc.tipo}</span>
                        
                        {/* Simulation download */}
                        <button
                          onClick={() => alert(`Inizio download del file: ${doc.nome}`)}
                          className="text-[9px] font-bold text-zinc-900 hover:underline flex items-center gap-1"
                        >
                          <Download className="h-3 w-3" /> Scarica
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* SUE MODULISTICA COMPILER OVERLAY */}
      <AnimatePresence>
        {showSueCompiler && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50" id="sue-compiler-modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4 text-zinc-900"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                <h3 className="text-base font-bold flex items-center gap-2">
                  <FileCheck className="h-5 w-5 text-zinc-900" /> SUE / SUAP Compiler
                </h3>
                <button onClick={() => setShowSueCompiler(false)} className="text-zinc-400 hover:text-zinc-600">✕</button>
              </div>

              <div className="space-y-3">
                <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/50">
                  <p className="text-xs text-zinc-600 font-medium">Auto-riempimento anagrafica abilitato per:</p>
                  <p className="text-sm font-bold text-zinc-800 mt-1">{activeClient?.name} {activeClient?.surname}</p>
                  <p className="text-xs text-zinc-400 font-mono mt-0.5">{activeClient?.cfPiva || 'CF non impostato'}</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Seleziona Modulistica Comunale</label>
                  <select
                    value={sueDocType}
                    onChange={(e) => setSueDocType(e.target.value)}
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                  >
                    <option value="CILA">CILA (Comunicazione Inizio Lavori Asseverata)</option>
                    <option value="SCIA">SCIA (Segnalazione Certificata Inizio Attività)</option>
                    <option value="Agibilita">Certificato di Agibilità Comunale</option>
                    <option value="PermessoCostruire">Permesso di Costruire (SUE)</option>
                  </select>
                </div>

                <div className="text-xs text-zinc-400 leading-relaxed pt-2">
                  Compilando questo modulo, verranno generati automaticamente i file PDF digitalmente timbrati dal tecnico responsabile <strong>{activeRole}</strong> per la presentazione ufficiale al portale SUE del comune di Ostuni.
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-100">
                <button type="button" onClick={() => setShowSueCompiler(false)} className="text-xs font-semibold text-zinc-500">Chiudi</button>
                <button
                  type="button"
                  onClick={handleCompileSUE}
                  disabled={isCompiling}
                  className="bg-zinc-950 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-sm hover:bg-zinc-800 disabled:bg-zinc-400"
                >
                  {isCompiling ? 'Generazione in corso...' : 'Compila e Firma Documento'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
