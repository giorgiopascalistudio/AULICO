/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Contact, Societa, CategoriaPersone, Interazione, Credential } from '../types';
import {
  Users,
  Plus,
  Search,
  Building,
  Mail,
  Phone,
  MapPin,
  FileText,
  Lock,
  Unlock,
  AlertTriangle,
  Award,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  EyeOff,
  Edit2,
  Trash2,
  Calendar,
  Gift,
  Share2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RegistroClientiViewProps {
  contacts: Contact[];
  onAddContact: (contact: Contact) => void;
  onUpdateContact: (contact: Contact) => void;
  onDeleteContact: (id: string) => void;
  activeSocieta: Societa;
  searchQuery: string;
}

export default function RegistroClientiView({
  contacts,
  onAddContact,
  onUpdateContact,
  onDeleteContact,
  activeSocieta,
  searchQuery
}: RegistroClientiViewProps) {
  // States
  const [selectedContact, setSelectedContact] = useState<Contact | null>(contacts[0] || null);
  const [activeTab, setActiveTab] = useState<'anagrafica' | 'brand' | 'credenziali' | 'storia'>('anagrafica');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editContact, setEditContact] = useState<Contact | null>(null);
  
  // Filter contacts by active company (societa) and global search query
  const [selectedCategory, setSelectedCategory] = useState<CategoriaPersone | 'Tutti'>('Tutti');

  const filteredContacts = contacts.filter((c) => {
    // Search match
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch =
      c.name.toLowerCase().includes(searchLower) ||
      c.surname.toLowerCase().includes(searchLower) ||
      (c.companyName && c.companyName.toLowerCase().includes(searchLower)) ||
      c.email.toLowerCase().includes(searchLower) ||
      c.phone.includes(searchLower) ||
      c.indirizzo.toLowerCase().includes(searchLower) ||
      c.targetCategoria.toLowerCase().includes(searchLower);

    // Company match (belongs to selected active company)
    const matchesCompany = c.societaCollegate.includes(activeSocieta);

    // Category match
    const matchesCategory = selectedCategory === 'Tutti' || c.categoria === selectedCategory;

    return matchesSearch && matchesCompany && matchesCategory;
  });

  // Toggle eye for password visibility
  const [visiblePasswords, setVisiblePasswords] = useState<{ [key: string]: boolean }>({});
  const togglePasswordVisibility = (credId: string) => {
    setVisiblePasswords((prev) => ({ ...prev, [credId]: !prev[credId] }));
  };

  // Add notes / interactions inside the detailed view
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteDesc, setNewNoteDesc] = useState('');
  const [newNoteTipo, setNewNoteTipo] = useState<'riunione' | 'evento' | 'campagna' | 'regalo'>('riunione');

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContact || !newNoteTitle || !newNoteDesc) return;

    const newInterazione: Interazione = {
      id: 'int-' + Date.now(),
      tipo: newNoteTipo,
      data: new Date().toISOString().split('T')[0],
      titolo: newNoteTitle,
      descrizione: newNoteDesc,
      dettagliAggiuntivi: newNoteTipo === 'regalo' ? 'Pensiero di Natale' : undefined
    };

    const updatedContact = {
      ...selectedContact,
      interazioni: [newInterazione, ...selectedContact.interazioni]
    };

    onUpdateContact(updatedContact);
    setSelectedContact(updatedContact);
    setNewNoteTitle('');
    setNewNoteDesc('');
  };

  // Form states for Create/Edit
  const [formName, setFormName] = useState('');
  const [formSurname, setFormSurname] = useState('');
  const [formCompanyName, setFormCompanyName] = useState('');
  const [formCfPiva, setFormCfPiva] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formCategory, setFormCategory] = useState<CategoriaPersone>('Clienti');
  const [formTargetCat, setFormTargetCat] = useState('');
  const [formFascia, setFormFascia] = useState<1 | 2 | 3>(2);
  const [formCanale, setFormCanale] = useState<'social' | 'sito' | 'passaparola' | 'agenzia' | 'altro'>('sito');
  const [formSocieta, setFormSocieta] = useState<Societa[]>([activeSocieta]);
  const [formLiberatoria, setFormLiberatoria] = useState(true);
  const [formRegolarita, setFormRegolarita] = useState(true);

  const resetForm = () => {
    setFormName('');
    setFormSurname('');
    setFormCompanyName('');
    setFormCfPiva('');
    setFormEmail('');
    setFormPhone('');
    setFormAddress('');
    setFormCategory('Clienti');
    setFormTargetCat('');
    setFormFascia(2);
    setFormCanale('sito');
    setFormSocieta([activeSocieta]);
    setFormLiberatoria(true);
    setFormRegolarita(true);
    setEditContact(null);
  };

  const openEditForm = (contact: Contact) => {
    setEditContact(contact);
    setFormName(contact.name);
    setFormSurname(contact.surname);
    setFormCompanyName(contact.companyName || '');
    setFormCfPiva(contact.cfPiva || '');
    setFormEmail(contact.email);
    setFormPhone(contact.phone);
    setFormAddress(contact.indirizzo);
    setFormCategory(contact.categoria);
    setFormTargetCat(contact.targetCategoria);
    setFormFascia(contact.fasciaImportanza);
    setFormCanale(contact.canaleAcquisizione);
    setFormSocieta(contact.societaCollegate);
    setFormLiberatoria(contact.liberatoriaPrivacyFirmata);
    setFormRegolarita(contact.regolaritaPagamenti);
    setShowAddForm(true);
  };

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formSurname || !formEmail || !formPhone) {
      alert('Per favore compila i campi obbligatori (Nome, Cognome, Email, Telefono)');
      return;
    }

    const contactPayload: Contact = {
      id: editContact ? editContact.id : 'contact-' + Date.now(),
      name: formName,
      surname: formSurname,
      companyName: formCompanyName,
      cfPiva: formCfPiva,
      email: formEmail,
      phone: formPhone,
      indirizzo: formAddress,
      categoria: formCategory,
      targetCategoria: formTargetCat || 'Generico',
      fasciaImportanza: formFascia,
      canaleAcquisizione: formCanale,
      societaCollegate: formSocieta,
      liberatoriaPrivacyFirmata: formLiberatoria,
      regolaritaPagamenti: formRegolarita,
      credenziali: editContact ? editContact.credenziali : [],
      interazioni: editContact ? editContact.interazioni : [],
      fasePipeline: editContact ? editContact.fasePipeline : 'primo_contatto',
      valorePipeline: editContact ? editContact.valorePipeline : 0,
      saldoDovuto: editContact ? editContact.saldoDovuto : 0,
      dataCreazione: editContact ? editContact.dataCreazione : new Date().toISOString().split('T')[0],
      brandAsset: editContact?.brandAsset || (formCategory === 'Clienti' ? {
        obiettivi: 'Nuovo progetto e valorizzazione d\'immagine.',
        tonoVoce: 'Moderno ed essenziale',
        targetRiferimento: 'Privati di lusso',
        assetGrafici: []
      } : undefined)
    };

    if (editContact) {
      onUpdateContact(contactPayload);
      if (selectedContact?.id === editContact.id) {
        setSelectedContact(contactPayload);
      }
    } else {
      onAddContact(contactPayload);
      setSelectedContact(contactPayload);
    }

    setShowAddForm(false);
    resetForm();
  };

  const toggleSocietaInForm = (soc: Societa) => {
    if (formSocieta.includes(soc)) {
      setFormSocieta(formSocieta.filter((s) => s !== soc));
    } else {
      setFormSocieta([...formSocieta, soc]);
    }
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full min-h-0 bg-zinc-50" id="registro-clienti-container">
      
      {/* LEFT LIST PANEL */}
      <div className="w-full md:w-1/2 flex flex-col border-r border-zinc-200/60 bg-white h-full min-h-0">
        
        {/* Sub-header with Category filters */}
        <div className="p-4 border-b border-zinc-100 flex flex-col gap-3" id="registro-filters-header">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-zinc-800" />
              <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Registro Unico Persone ({activeSocieta})</h2>
            </div>
            <button
              onClick={() => {
                resetForm();
                setShowAddForm(true);
              }}
              className="bg-zinc-950 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm hover:bg-zinc-800 transition-colors"
              id="btn-add-contact"
            >
              <Plus className="h-4 w-4" /> Nuovo Contatto
            </button>
          </div>

          {/* Horizontal scroll category filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none" id="category-selector-pills">
            {(['Tutti', 'Clienti', 'Investitori', 'Fornitori e Imprese', 'Agenzie Immobiliari', 'Sponsor e Conoscenti', 'Figure Istituzionali'] as const).map((cat) => {
              const isCatActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                    isCatActive ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'
                  }`}
                  id={`cat-pill-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* List of filtered contacts */}
        <div className="flex-1 overflow-y-auto divide-y divide-zinc-100" id="contact-list-container">
          {filteredContacts.length === 0 ? (
            <div className="p-8 text-center text-zinc-400 text-sm">
              Nessun contatto trovato con i filtri correnti.
            </div>
          ) : (
            filteredContacts.map((c) => {
              const isSelected = selectedContact?.id === c.id;
              return (
                <div
                  key={c.id}
                  onClick={() => {
                    setSelectedContact(c);
                    setActiveTab('anagrafica');
                  }}
                  className={`p-4 flex items-start gap-3 cursor-pointer transition-all ${
                    isSelected ? 'bg-zinc-50/80 border-l-4 border-zinc-900' : 'hover:bg-zinc-50/40'
                  }`}
                  id={`contact-item-${c.id}`}
                >
                  {/* Status lights & Icon */}
                  <div className="relative pt-1">
                    <div className="h-9 w-9 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700 font-bold text-sm border border-zinc-200/50">
                      {c.name[0]}{c.surname[0]}
                    </div>
                    {/* Regolarità Pagamenti Indicator */}
                    <span
                      className={`absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-white ${
                        c.regolaritaPagamenti ? 'bg-emerald-500' : 'bg-red-500 animate-pulse'
                      }`}
                      title={c.regolaritaPagamenti ? 'In regola con i pagamenti' : 'PAGAMENTO IN SOSPESO / MOROSITÀ'}
                    ></span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-zinc-900 truncate">
                        {c.name} {c.surname}
                      </h3>
                      <span className="text-[10px] font-semibold uppercase tracking-wider bg-zinc-100 text-zinc-600 px-2 py-0.5 rounded-full">
                        {c.categoria}
                      </span>
                    </div>

                    {c.companyName && (
                      <p className="text-xs text-zinc-500 truncate mt-0.5 font-medium">{c.companyName}</p>
                    )}

                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      {/* Fascia Badge */}
                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded flex items-center gap-1 ${
                        c.fasciaImportanza === 1 ? 'bg-red-50 text-red-700 font-semibold' :
                        c.fasciaImportanza === 2 ? 'bg-amber-50 text-amber-700' : 'bg-blue-50 text-blue-700'
                      }`}>
                        Fascia {c.fasciaImportanza}
                      </span>

                      {/* Acquisition Channel Badge */}
                      <span className="text-[10px] bg-zinc-50 text-zinc-500 border border-zinc-100 px-1.5 py-0.5 rounded capitalize">
                        {c.canaleAcquisizione}
                      </span>

                      {/* Privacy release alert icon */}
                      {!c.liberatoriaPrivacyFirmata && (
                        <span className="text-[10px] bg-red-100 text-red-800 font-semibold px-1.5 py-0.5 rounded flex items-center gap-1">
                          <AlertTriangle className="h-3 w-3" /> NO LIBERATORIA
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT DETAILED VIEW PANEL (Vista Dedicata) */}
      <div className="flex-1 flex flex-col bg-white h-full min-h-0 relative shadow-inner">
        {selectedContact ? (
          <div className="flex-1 flex flex-col h-full min-h-0" id="contact-detail-panel">
            
            {/* Detail Header */}
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="h-14 w-14 rounded-full bg-zinc-900 text-white flex items-center justify-center font-bold text-lg font-mono">
                  {selectedContact.name[0]}{selectedContact.surname[0]}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h1 className="text-xl font-bold text-zinc-900">
                      {selectedContact.name} {selectedContact.surname}
                    </h1>
                    <span className="text-xs bg-zinc-100 font-bold text-zinc-700 px-2.5 py-0.5 rounded-full uppercase">
                      {selectedContact.categoria}
                    </span>
                  </div>
                  {selectedContact.companyName && (
                    <p className="text-sm text-zinc-500 font-medium mt-0.5">{selectedContact.companyName}</p>
                  )}
                  {/* Connected companies list with checkmarks */}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider mr-1">Società:</span>
                    {Object.values(Societa).map((soc) => {
                      const isLinked = selectedContact.societaCollegate.includes(soc);
                      return (
                        <span
                          key={soc}
                          className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase transition-all ${
                            isLinked
                              ? 'bg-zinc-900 text-white'
                              : 'bg-zinc-100 text-zinc-300'
                          }`}
                        >
                          {soc}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 self-stretch md:self-auto justify-end">
                <button
                  onClick={() => openEditForm(selectedContact)}
                  className="p-2 text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100 border border-zinc-200 rounded-lg text-sm flex items-center gap-1"
                  id="btn-edit-contact"
                >
                  <Edit2 className="h-4 w-4" /> Modifica
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Sei sicuro di voler eliminare ${selectedContact.name} ${selectedContact.surname}?`)) {
                      onDeleteContact(selectedContact.id);
                      setSelectedContact(null);
                    }
                  }}
                  className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 border border-red-200/50 rounded-lg text-sm"
                  id="btn-delete-contact"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* BLOCKING PRIVACY WARNING IF MISSING */}
            {!selectedContact.liberatoriaPrivacyFirmata && (
              <div className="bg-red-500 text-white px-6 py-3.5 flex items-center gap-3 font-semibold shadow-md animate-pulse shrink-0" id="privacy-alert-banner">
                <AlertTriangle className="h-6 w-6 animate-bounce text-yellow-300" />
                <div className="text-sm">
                  <p className="font-extrabold uppercase tracking-wider">🔴 SEZIONE MARKETING: VIETATO PUBBLICARE NULLA!</p>
                  <p className="text-xs text-red-100 font-medium">La liberatoria per l'uso delle immagini e dei video di cantiere NON è stata firmata dal cliente.</p>
                </div>
              </div>
            )}

            {/* Tabs selector */}
            <div className="border-b border-zinc-100 bg-white px-6" id="detail-tabs">
              <div className="flex items-center gap-6">
                {[
                  { id: 'anagrafica', label: 'Anagrafica & Target', icon: FileText },
                  { id: 'brand', label: 'Asset del Brand', icon: Share2 },
                  { id: 'credenziali', label: 'Credenziali Protette', icon: Lock },
                  { id: 'storia', label: 'Memoria Interazioni', icon: Clock }
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isTabActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-2 py-3.5 text-sm font-semibold border-b-2 transition-all ${
                        isTabActive
                          ? 'border-zinc-950 text-zinc-950'
                          : 'border-transparent text-zinc-400 hover:text-zinc-600'
                      }`}
                      id={`tab-btn-${tab.id}`}
                    >
                      <Icon className="h-4 w-4" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* TAB CONTENTS */}
            <div className="flex-1 overflow-y-auto p-6" id="detail-tab-content">
              
              {/* ANAGRAFICA TAB */}
              {activeTab === 'anagrafica' && (
                <div className="space-y-6" id="tab-anagrafica-pane">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Base Details Card */}
                    <div className="bg-zinc-50 border border-zinc-100 p-4 rounded-xl space-y-4">
                      <h3 className="font-bold text-sm text-zinc-800 uppercase tracking-wider">Contatti & Recapiti</h3>
                      
                      <div className="flex items-center gap-3">
                        <Mail className="h-4 w-4 text-zinc-400" />
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">EMAIL</p>
                          <a href={`mailto:${selectedContact.email}`} className="text-sm font-medium text-zinc-800 hover:underline">
                            {selectedContact.email}
                          </a>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Phone className="h-4 w-4 text-zinc-400" />
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">TELEFONO</p>
                          <a href={`tel:${selectedContact.phone}`} className="text-sm font-medium text-zinc-800 hover:underline">
                            {selectedContact.phone}
                          </a>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <MapPin className="h-4 w-4 text-zinc-400" />
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">INDIRIZZO</p>
                          <p className="text-sm font-medium text-zinc-800">{selectedContact.indirizzo}</p>
                        </div>
                      </div>
                    </div>

                    {/* Operational Details Card */}
                    <div className="bg-zinc-50 border border-zinc-100 p-4 rounded-xl space-y-4">
                      <h3 className="font-bold text-sm text-zinc-800 uppercase tracking-wider">Profilazione Strategica</h3>
                      
                      <div>
                        <p className="text-[10px] text-zinc-400 font-bold uppercase">CODICE FISCALE / PARTITA IVA</p>
                        <p className="text-sm font-mono font-semibold text-zinc-800 mt-0.5">
                          {selectedContact.cfPiva || 'NON FORNITO'}
                        </p>
                      </div>

                      <div>
                        <p className="text-[10px] text-zinc-400 font-bold uppercase">TARGET E CATEGORIA SPECIFICA</p>
                        <p className="text-sm font-semibold text-zinc-800 mt-0.5 bg-white border border-zinc-200/50 rounded-lg px-3 py-1.5 inline-block">
                          🎯 {selectedContact.targetCategoria}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">FASCIA IMPORTANZA</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <span className="h-6 w-6 rounded-full bg-zinc-900 text-white text-xs font-bold flex items-center justify-center">
                              {selectedContact.fasciaImportanza}
                            </span>
                            <span className="text-xs font-semibold text-zinc-700">
                              {selectedContact.fasciaImportanza === 1 ? 'Alto Valore (Fascia 1)' :
                               selectedContact.fasciaImportanza === 2 ? 'Medio Valore (Fascia 2)' : 'Standard (Fascia 3)'}
                            </span>
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">CANALE ACQUISIZIONE</p>
                          <p className="text-xs font-bold uppercase text-zinc-700 mt-1.5">
                            {selectedContact.canaleAcquisizione}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Financial indicators visual checklist */}
                  <div className="bg-zinc-50 border border-zinc-100 p-4 rounded-xl">
                    <h3 className="font-bold text-sm text-zinc-800 uppercase tracking-wider mb-3">Checklist Amministrativa</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3 bg-white p-3 rounded-lg border border-zinc-100">
                        {selectedContact.regolaritaPagamenti ? (
                          <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 shrink-0 animate-ping" />
                        )}
                        <div>
                          <p className="text-xs font-bold text-zinc-700">REGOLARITÀ NEI PAGAMENTI</p>
                          <p className={`text-xs ${selectedContact.regolaritaPagamenti ? 'text-emerald-600 font-medium' : 'text-red-600 font-extrabold'}`}>
                            {selectedContact.regolaritaPagamenti ? 'Regolare con tutti i saldi' : 'MOROSO / DOWNLOAD BLOCKED'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 bg-white p-3 rounded-lg border border-zinc-100">
                        {selectedContact.liberatoriaPrivacyFirmata ? (
                          <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
                        )}
                        <div>
                          <p className="text-xs font-bold text-zinc-700">LIBERATORIA PRIVACY IMMAGINI</p>
                          <p className={`text-xs ${selectedContact.liberatoriaPrivacyFirmata ? 'text-emerald-600 font-medium' : 'text-red-500 font-extrabold animate-pulse'}`}>
                            {selectedContact.liberatoriaPrivacyFirmata ? 'Firmata' : 'NON FIRMATA - VIETATA PUBBLICAZIONE'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* BRAND ASSETS TAB */}
              {activeTab === 'brand' && (
                <div className="space-y-6" id="tab-brand-pane">
                  {selectedContact.brandAsset ? (
                    <div className="space-y-6">
                      <div className="bg-zinc-50 border border-zinc-100 p-5 rounded-xl space-y-4">
                        <h3 className="font-bold text-sm text-zinc-800 uppercase tracking-wider">Identità Strategica del Brand</h3>
                        
                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">OBIETTIVI DEL CLIENTE</p>
                          <p className="text-sm font-medium text-zinc-800 mt-1">{selectedContact.brandAsset.obiettivi}</p>
                        </div>

                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">TONO DI VOCE</p>
                          <p className="text-sm font-medium text-zinc-800 mt-1">{selectedContact.brandAsset.tonoVoce}</p>
                        </div>

                        <div>
                          <p className="text-[10px] text-zinc-400 font-bold uppercase">TARGET DI RIFERIMENTO</p>
                          <p className="text-sm font-medium text-zinc-800 mt-1">{selectedContact.brandAsset.targetRiferimento}</p>
                        </div>
                      </div>

                      {/* Mock Graphical files */}
                      <div className="space-y-2">
                        <p className="text-[10px] text-zinc-400 font-bold uppercase">ASSET GRAFICI E ALLEGATI</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {selectedContact.brandAsset.assetGrafici.length === 0 ? (
                            <p className="text-xs text-zinc-400">Nessun file grafico allegato.</p>
                          ) : (
                            selectedContact.brandAsset.assetGrafici.map((file, idx) => (
                              <div key={idx} className="flex items-center justify-between bg-zinc-50 p-3 rounded-lg border border-zinc-200/50">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-zinc-500" />
                                  <span className="text-xs font-semibold text-zinc-700 truncate max-w-xs">{file}</span>
                                </div>
                                <span className="text-[9px] bg-zinc-200 text-zinc-600 px-1.5 py-0.5 rounded font-mono">ASSET</span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-8 bg-zinc-50 rounded-xl border border-dashed border-zinc-200">
                      <p className="text-sm text-zinc-400 font-medium">Questa sezione Brand Asset è dedicata esclusivamente ai contatti profilati come Clienti marketing.</p>
                    </div>
                  )}
                </div>
              )}

              {/* CREDENTIALS TAB */}
              {activeTab === 'credenziali' && (
                <div className="space-y-4" id="tab-credenziali-pane">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-zinc-800 uppercase tracking-wider">Credenziali & Password Protette</h3>
                    <span className="text-xs bg-red-50 text-red-700 font-semibold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Lock className="h-3.5 w-3.5" /> Accesso Riservato Amministrazione
                    </span>
                  </div>

                  <div className="space-y-3">
                    {selectedContact.credenziali.length === 0 ? (
                      <div className="text-center py-6 bg-zinc-50 rounded-xl border border-dashed border-zinc-200 text-zinc-400 text-xs">
                        Nessuna credenziale salvata per questo contatto. Puoi aggiungerle modificando il contatto.
                      </div>
                    ) : (
                      selectedContact.credenziali.map((cred) => {
                        const isVisible = visiblePasswords[cred.id];
                        return (
                          <div key={cred.id} className="bg-zinc-50 p-4 rounded-xl border border-zinc-200/50 space-y-2">
                            <div className="flex items-center justify-between border-b border-zinc-200/60 pb-2">
                              <span className="text-xs font-bold text-zinc-900 uppercase tracking-wider">{cred.service}</span>
                              <button
                                onClick={() => togglePasswordVisibility(cred.id)}
                                className="text-zinc-500 hover:text-zinc-950 p-1 rounded hover:bg-zinc-200 transition-colors"
                              >
                                {isVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </button>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-xs pt-1">
                              <div>
                                <p className="text-[9px] text-zinc-400 font-bold uppercase">UTENTE / USERNAME</p>
                                <p className="font-mono font-semibold text-zinc-700 mt-0.5">{cred.username}</p>
                              </div>
                              <div>
                                <p className="text-[9px] text-zinc-400 font-bold uppercase">PASSWORD</p>
                                <p className="font-mono font-semibold text-zinc-700 mt-0.5 tracking-wider">
                                  {isVisible ? cred.password : '••••••••••••'}
                                </p>
                              </div>
                            </div>

                            {cred.note && (
                              <p className="text-[10px] text-zinc-400 italic mt-2 pt-2 border-t border-zinc-200/30">
                                Note: {cred.note}
                              </p>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* INTERACTION MEMORY TAB */}
              {activeTab === 'storia' && (
                <div className="space-y-6" id="tab-storia-pane">
                  
                  {/* Note adding Form */}
                  <form onSubmit={handleAddNote} className="bg-zinc-50 p-4 rounded-xl border border-zinc-200/50 space-y-3">
                    <h4 className="font-bold text-xs text-zinc-700 uppercase tracking-wider">Nuovo appunto di riunione / Interazione</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Titolo dell'appunto o evento"
                        value={newNoteTitle}
                        onChange={(e) => setNewNoteTitle(e.target.value)}
                        className="p-2 border border-zinc-200 rounded text-xs bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900"
                        required
                      />
                      <select
                        value={newNoteTipo}
                        onChange={(e: any) => setNewNoteTipo(e.target.value)}
                        className="p-2 border border-zinc-200 rounded text-xs bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900"
                      >
                        <option value="riunione">Riunione (Minute / Note)</option>
                        <option value="evento">Partecipazione ad Eventi</option>
                        <option value="campagna">Campagna di Marketing</option>
                        <option value="regalo">Pensieri & Gadget (Regali)</option>
                      </select>
                    </div>
                    <textarea
                      placeholder="Sintesi dettagliata delle decisioni prese o dettagli del gadget..."
                      value={newNoteDesc}
                      onChange={(e) => setNewNoteDesc(e.target.value)}
                      className="w-full p-2 border border-zinc-200 rounded text-xs bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900 h-20"
                      required
                    ></textarea>
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-semibold px-3.5 py-1.5 rounded transition-all"
                      >
                        Salva Appunto
                      </button>
                    </div>
                  </form>

                  {/* Historic timeline of interactions */}
                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-zinc-700 uppercase tracking-wider">Storico Completo</h4>
                    
                    {selectedContact.interazioni.length === 0 ? (
                      <p className="text-xs text-zinc-400 italic">Ancora nessuna interazione registrata.</p>
                    ) : (
                      <div className="relative border-l border-zinc-200 pl-4 space-y-5 ml-2">
                        {selectedContact.interazioni.map((it) => (
                          <div key={it.id} className="relative" id={`interaction-timeline-${it.id}`}>
                            {/* Icon marker based on type */}
                            <span className={`absolute -left-[25px] top-0.5 h-4 w-4 rounded-full flex items-center justify-center text-white text-[8px] font-bold ${
                              it.tipo === 'riunione' ? 'bg-indigo-600' :
                              it.tipo === 'evento' ? 'bg-amber-500' :
                              it.tipo === 'campagna' ? 'bg-emerald-600' : 'bg-rose-500'
                            }`}>
                              {it.tipo === 'riunione' ? <FileText className="h-2 w-2" /> :
                               it.tipo === 'evento' ? <Calendar className="h-2 w-2" /> :
                               it.tipo === 'campagna' ? <Share2 className="h-2 w-2" /> : <Gift className="h-2 w-2" />}
                            </span>
                            
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-semibold text-zinc-400 font-mono">{it.data}</span>
                                <span className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                                  it.tipo === 'riunione' ? 'bg-indigo-50 text-indigo-700' :
                                  it.tipo === 'evento' ? 'bg-amber-50 text-amber-700' :
                                  it.tipo === 'campagna' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                                }`}>
                                  {it.tipo}
                                </span>
                              </div>
                              <h5 className="text-xs font-bold text-zinc-800 mt-1">{it.titolo}</h5>
                              <p className="text-xs text-zinc-600 mt-0.5 leading-relaxed">{it.descrizione}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-zinc-400 text-sm">
            Seleziona un contatto per vederne i dettagli o creane uno nuovo.
          </div>
        )}
      </div>

      {/* CREATE / EDIT CONTACT MODAL OVERLAY */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="contact-form-modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-zinc-100 bg-zinc-50 flex items-center justify-between shrink-0">
                <h3 className="text-lg font-bold text-zinc-900">
                  {editContact ? 'Modifica Contatto' : 'Inserisci Nuovo Contatto'}
                </h3>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    resetForm();
                  }}
                  className="text-zinc-400 hover:text-zinc-600 text-lg font-bold"
                >
                  ✕
                </button>
              </div>

              {/* Form body */}
              <form onSubmit={handleSaveContact} className="p-6 overflow-y-auto space-y-4 flex-1">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Nome *</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Cognome *</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formSurname}
                      onChange={(e) => setFormSurname(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Ragione Sociale (Opzionale)</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formCompanyName}
                      onChange={(e) => setFormCompanyName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Codice Fiscale / P.IVA</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formCfPiva}
                      onChange={(e) => setFormCfPiva(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Email *</label>
                    <input
                      type="email"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Telefono *</label>
                    <input
                      type="text"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Indirizzo Completo</label>
                  <input
                    type="text"
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                    placeholder="Es. C.da Vado Aperto, Ostuni"
                    value={formAddress}
                    onChange={(e) => setFormAddress(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Categoria Persona</label>
                    <select
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:outline-none"
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as CategoriaPersone)}
                    >
                      <option value="Clienti">Clienti</option>
                      <option value="Investitori">Investitori</option>
                      <option value="Fornitori e Imprese">Fornitori e Imprese</option>
                      <option value="Agenzie Immobiliari">Agenzie Immobiliari</option>
                      <option value="Sponsor e Conoscenti">Sponsor e Conoscenti</option>
                      <option value="Figure Istituzionali">Figure Istituzionali</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Target e Categoria Specifica</label>
                    <input
                      type="text"
                      placeholder="Es. Imprese di Ostuni, Agenzie lusso"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:bg-white focus:outline-none"
                      value={formTargetCat}
                      onChange={(e) => setFormTargetCat(e.target.value)}
                    />
                  </div>
                </div>

                {/* Sytem of check-boxes for multiple Company affiliation */}
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase mb-1">Appartenenza Societaria (Multipla)</label>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {Object.values(Societa).map((soc) => {
                      const selected = formSocieta.includes(soc);
                      return (
                        <button
                          type="button"
                          key={soc}
                          onClick={() => toggleSocietaInForm(soc)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 border ${
                            selected
                              ? 'bg-zinc-950 text-white border-transparent'
                              : 'bg-zinc-50 text-zinc-500 border-zinc-200 hover:bg-zinc-100'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={selected}
                            onChange={() => {}} // Controlled by button click
                            className="rounded text-zinc-900 focus:ring-0 h-3 w-3"
                          />
                          {soc}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Fascia di Importanza</label>
                    <select
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:outline-none"
                      value={formFascia}
                      onChange={(e) => setFormFascia(parseInt(e.target.value) as any)}
                    >
                      <option value={1}>Fascia 1 (Valore Elevato)</option>
                      <option value={2}>Fascia 2 (Valore Medio)</option>
                      <option value={3}>Fascia 3 (Valore Standard)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Canale di Acquisizione</label>
                    <select
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50 focus:outline-none"
                      value={formCanale}
                      onChange={(e) => setFormCanale(e.target.value as any)}
                    >
                      <option value="social">Social Media (Instagram/Facebook)</option>
                      <option value="sito">Sito Web Aziendale</option>
                      <option value="passaparola">Passaparola / Raccomandazione</option>
                      <option value="agenzia">Agenzia Immobiliare Partner</option>
                      <option value="altro">Altro</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 border-t border-zinc-100 pt-4">
                  <div className="flex items-center justify-between bg-zinc-50 p-3 rounded-xl border border-zinc-100">
                    <div>
                      <span className="text-xs font-bold text-zinc-700 block">Liberatoria Privacy Video</span>
                      <span className="text-[10px] text-zinc-400">Firmata per foto e video di cantiere?</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={formLiberatoria}
                      onChange={(e) => setFormLiberatoria(e.target.checked)}
                      className="rounded text-zinc-950 focus:ring-zinc-950 h-5 w-5 cursor-pointer accent-zinc-900"
                    />
                  </div>

                  <div className="flex items-center justify-between bg-zinc-50 p-3 rounded-xl border border-zinc-100">
                    <div>
                      <span className="text-xs font-bold text-zinc-700 block">Regolarità Pagamenti</span>
                      <span className="text-[10px] text-zinc-400">In regola con tutti i saldi?</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={formRegolarita}
                      onChange={(e) => setFormRegolarita(e.target.checked)}
                      className="rounded text-zinc-950 focus:ring-zinc-950 h-5 w-5 cursor-pointer accent-zinc-900"
                    />
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="flex items-center justify-end gap-3 border-t border-zinc-100 pt-5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      resetForm();
                    }}
                    className="px-4 py-2 text-sm font-semibold text-zinc-600 hover:text-zinc-900"
                  >
                    Annulla
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-sm font-semibold shadow-sm"
                  >
                    Salva Contatto
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
