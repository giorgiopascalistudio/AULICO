/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Layers, CheckCircle2, Circle, Clock, MessageSquare, Flame } from 'lucide-react';

interface CicloTask {
  id: number;
  titolo: string;
  fase: string;
  priorita: 'alta' | 'media' | 'bassa';
  completato: boolean;
  descrizione: string;
}

export default function ListaCicliView() {
  const [cicli, setCicli] = useState<CicloTask[]>([
    { id: 1, titolo: '01. Inquadramento Urbanistico - Gioia Mariagrazia', fase: 'Pianificazione', priorita: 'alta', completato: true, descrizione: 'Verificare indici volumetrici di edificabilità con piscina e distanze confini.' },
    { id: 2, titolo: '02. Rilievo Topografico con drone - Bell Alan', fase: 'Pianificazione', priorita: 'media', completato: true, descrizione: 'Acquisizione nuvola di punti e curve di livello del terreno piantumato ad olivi.' },
    { id: 3, titolo: '03. Computo Metrico Estimativo - Ayroldi Maria', fase: 'Progettazione', priorita: 'alta', completato: false, descrizione: 'Definire capitolato per arredi in legno massello e finiture in pietra trani.' },
    { id: 4, titolo: '04. Pratica CILA SUE - Bennardo Gianluca', fase: 'Abilitativa', priorita: 'media', completato: false, descrizione: 'Presentazione asseverata al SUE per interventi di restauro conservativo.' },
    { id: 5, titolo: '05. Fine lavori & Agibilità - Carlens Jacques', fase: 'Abilitativa', priorita: 'bassa', completato: false, descrizione: 'Collaudi impianti, accatastamento ed emissione agibilità.' }
  ]);

  const [nuovoPianoTask, setNuovoPianoTask] = useState('');
  const [pianoAttacchi, setPianoAttacchi] = useState([
    { id: 1, text: '🔥 Sbloccare pratica agibilità Carlens Jacques', data: 'Entro Lunedì' },
    { id: 2, text: '📍 Sopralluogo Ostuni C.da Cinera', data: 'Mercoledì ore 10:00' },
    { id: 3, text: '📧 Inviare preventivo revisionato a James Bichard', data: 'Giovedì' }
  ]);

  const handleToggleCiclo = (id: number) => {
    setCicli(cicli.map((c) => (c.id === id ? { ...c, completato: !c.completato } : c)));
  };

  const handleAddPiano = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuovoPianoTask) return;
    setPianoAttacchi([
      ...pianoAttacchi,
      { id: Date.now(), text: nuovoPianoTask, data: 'Da pianificare' }
    ]);
    setNuovoPianoTask('');
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50 overflow-hidden" id="lista-cicli-module">
      
      {/* Header */}
      <div className="bg-white border-b border-zinc-100 px-6 py-4 shrink-0">
        <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Lista dei Cicli & Piano di Battaglia</h2>
        <p className="text-xs text-zinc-400 mt-0.5">Controllo strategico e operativo dei cicli di lavoro e delle priorità d'assalto del team.</p>
      </div>

      <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-6" id="lista-cicli-content-grid">
        
        {/* LEFT COLUMN: LISTA DEI CICLI */}
        <div className="bg-white rounded-3xl border border-zinc-200/60 p-6 shadow-2xs flex flex-col h-[520px]" id="lista-cicli-pane">
          <div className="border-b border-zinc-100 pb-3 mb-4 shrink-0">
            <h3 className="text-base font-black text-red-600 tracking-wider">LISTA DEI CICLI</h3>
            <p className="text-xs text-zinc-400 mt-0.5">Stato di avanzamento dei cicli operativi per ciascun cantiere.</p>
          </div>

          <div className="flex-1 overflow-y-auto space-y-3 pr-1" id="cicli-scrollable-container">
            {cicli.map((c) => (
              <div
                key={c.id}
                onClick={() => handleToggleCiclo(c.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                  c.completato
                    ? 'bg-zinc-50 border-zinc-200/50 opacity-70'
                    : 'bg-white border-zinc-200 hover:border-zinc-950 hover:shadow-xs'
                }`}
              >
                {c.completato ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                ) : (
                  <Circle className="h-5 w-5 text-zinc-300 shrink-0 mt-0.5 hover:text-zinc-500" />
                )}

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className={`text-xs font-bold leading-tight ${c.completato ? 'line-through text-zinc-400' : 'text-zinc-850'}`}>
                      {c.titolo}
                    </h4>
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                      c.priorita === 'alta' ? 'bg-red-50 text-red-700' :
                      c.priorita === 'media' ? 'bg-amber-50 text-amber-700' : 'bg-blue-50 text-blue-700'
                    }`}>
                      {c.priorita}
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-1 leading-relaxed">{c.descrizione}</p>
                  <span className="text-[9px] bg-zinc-100 text-zinc-600 px-1.5 py-0.2 rounded font-semibold inline-block mt-2">
                    Fase: {c.fase}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT COLUMN: PIANO DI BATTAGLIA */}
        <div className="bg-white rounded-3xl border border-zinc-200/60 p-6 shadow-2xs flex flex-col h-[520px]" id="piano-battaglia-pane">
          <div className="border-b border-zinc-100 pb-3 mb-4 shrink-0">
            <h3 className="text-base font-black text-red-600 tracking-wider">PIANO DI BATTAGLIA</h3>
            <p className="text-xs text-zinc-400 mt-0.5">Assalti strategici immediati da compiere per espandere il business.</p>
          </div>

          <div className="flex-1 overflow-y-auto space-y-3.5 pr-1" id="piano-scrollable-container">
            {pianoAttacchi.map((item) => (
              <div key={item.id} className="p-3.5 bg-red-50/20 border border-red-100/40 rounded-2xl flex items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-2.5">
                  <Flame className="h-4.5 w-4.5 text-red-500 shrink-0" />
                  <span className="text-xs font-bold text-zinc-800 leading-snug">{item.text}</span>
                </div>
                <span className="text-[9px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded font-mono shrink-0 whitespace-nowrap">
                  {item.data}
                </span>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddPiano} className="mt-4 pt-3 border-t border-zinc-100 space-y-2 shrink-0">
            <input
              type="text"
              placeholder="Inserisci un nuovo assalto strategico..."
              value={nuovoPianoTask}
              onChange={(e) => setNuovoPianoTask(e.target.value)}
              className="w-full p-2.5 border border-zinc-200 rounded-xl text-xs bg-zinc-50 focus:outline-none"
              required
            />
            <button
              type="submit"
              className="w-full bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-bold py-2.5 rounded-xl shadow-xs"
            >
              Pubblica nel Piano di Battaglia
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
