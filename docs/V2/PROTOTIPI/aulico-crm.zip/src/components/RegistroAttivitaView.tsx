/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ClipboardList, Trash2, Edit, Plus, RefreshCw, Filter } from 'lucide-react';

interface LogEntry {
  id: string;
  azione: 'Creazione' | 'Eliminazione' | 'Modifica' | 'Ripristino';
  descrizione: string;
  operatore: string;
  data: string;
  area: string;
}

export default function RegistroAttivitaView() {
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: 'log-1', azione: 'Eliminazione', descrizione: 'Eliminato cantiere test_3 dal registro progetti', operatore: 'Dario Fiore', data: '2026-06-26 09:30', area: 'Progetti' },
    { id: 'log-2', azione: 'Eliminazione', descrizione: 'Eliminato cantiere test-2 dal registro progetti', operatore: 'Dario Fiore', data: '2026-06-26 09:30', area: 'Progetti' },
    { id: 'log-3', azione: 'Creazione', descrizione: 'Registrato nuovo preventivo PREV-2026-001 per Gioia Mariagrazia', operatore: 'Dario Fiore', data: '2026-06-25 15:10', area: 'Commerciale' },
    { id: 'log-4', azione: 'Modifica', descrizione: 'Aggiornati punti del piano incentivante per Raffaele Zivoli', operatore: 'Francesco Zurlo', data: '2026-06-24 11:22', area: 'Amministrazione' },
    { id: 'log-5', azione: 'Modifica', descrizione: 'Modificato indirizzo di Ayroldi Maria in Piazza Gino Zaccaria', operatore: 'Dario Fiore', data: '2026-06-23 18:02', area: 'Clienti' }
  ]);

  const [filterAzione, setFilterAzione] = useState<string>('Tutti');

  const filteredLogs = filterAzione === 'Tutti' 
    ? logs 
    : logs.filter((l) => l.azione === filterAzione);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-zinc-50" id="registro-attivita-module">
      
      {/* Header info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-zinc-950 tracking-tight">Registro delle Attività (Audit Trail)</h2>
          <p className="text-xs text-zinc-400 mt-1">Traccia delle azioni dello studio (creazioni, modifiche, eliminazioni). Sola lettura per controllo qualità.</p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2" id="logs-filter-container">
          <Filter className="h-4 w-4 text-zinc-400" />
          <select
            value={filterAzione}
            onChange={(e) => setFilterAzione(e.target.value)}
            className="p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-white focus:outline-none"
          >
            <option value="Tutti">Tutti i tipi di azione</option>
            <option value="Creazione">Creazione</option>
            <option value="Modifica">Modifica</option>
            <option value="Eliminazione">Eliminazione</option>
          </select>
        </div>
      </div>

      {/* Log list list */}
      <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-2xs">
        <div className="p-4 bg-zinc-50 border-b border-zinc-100 flex items-center justify-between text-xs font-bold text-zinc-400 shrink-0">
          <span>Storico Operazioni</span>
          <span>Aggiornato in tempo reale</span>
        </div>

        <div className="divide-y divide-zinc-100" id="logs-list-rows">
          {filteredLogs.map((log) => (
            <div key={log.id} className="p-4 flex items-start gap-3 hover:bg-zinc-50/40 text-xs">
              
              {/* Action indicator badge */}
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                log.azione === 'Creazione' ? 'bg-emerald-50 text-emerald-700' :
                log.azione === 'Eliminazione' ? 'bg-red-50 text-red-700' :
                log.azione === 'Modifica' ? 'bg-blue-50 text-blue-700' : 'bg-zinc-100 text-zinc-700'
              }`}>
                {log.azione}
              </span>

              <div className="flex-1 min-w-0 space-y-0.5">
                <p className="font-semibold text-zinc-900 leading-tight">{log.descrizione}</p>
                <div className="flex items-center gap-2 text-[10px] text-zinc-400">
                  <span>Operatore: <strong>{log.operatore}</strong></span>
                  <span>•</span>
                  <span>Area: <strong>{log.area}</strong></span>
                </div>
              </div>

              <span className="text-[10px] text-zinc-400 font-mono shrink-0 font-semibold">{log.data}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
