/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Contact, Preventivo, AttivitaTecnico } from '../types';
import {
  TrendingUp,
  FileText,
  User,
  Plus,
  ShieldCheck,
  Smartphone,
  Calendar,
  AlertCircle,
  Clock,
  ArrowRight,
  Filter,
  Briefcase,
  CheckCircle,
  Archive
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CommercialeViewProps {
  contacts: Contact[];
  preventivi: Preventivo[];
  attivita: AttivitaTecnico[];
  onAddPreventivo: (prev: Preventivo) => void;
  onUpdatePreventivo: (prev: Preventivo) => void;
  onAddAttivita: (act: AttivitaTecnico) => void;
  onUpdateContactPhase: (id: string, phase: any) => void;
}

const STAGES = [
  { id: 'primo_contatto', label: 'Nuovo Contatto', color: 'bg-zinc-100 text-zinc-700' },
  { id: 'attesa_preventivo', label: 'In Attesa di Preventivo', color: 'bg-amber-100 text-amber-700' },
  { id: 'preventivo', label: 'Preventivo Elaborato', color: 'bg-indigo-100 text-indigo-700' },
  { id: 'negoziazione', label: 'Negoziazione', color: 'bg-blue-100 text-blue-700' },
  { id: 'contratto_firmato', label: 'Contratto Firmato', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'perso', label: 'Perso', color: 'bg-red-100 text-red-700' }
] as const;

export default function CommercialeView({
  contacts,
  preventivi,
  attivita,
  onAddPreventivo,
  onUpdatePreventivo,
  onAddAttivita,
  onUpdateContactPhase
}: CommercialeViewProps) {
  // Views inside Commerciale: 'pipeline' or 'preventivi'
  const [subSection, setSubSection] = useState<'pipeline' | 'preventivi'>('pipeline');
  
  // Create Preventivo modal
  const [showCreatePrevModal, setShowCreatePrevModal] = useState(false);
  const [newPrevClient, setNewPrevClient] = useState('');
  const [newPrevTitle, setNewPrevTitle] = useState('');
  const [newPrevAmount, setNewPrevAmount] = useState(10000);
  const [newPrevDays, setNewPrevDays] = useState(30);
  const [newPrevTecnico, setNewPrevTecnico] = useState('Raffaele Zivoli');

  // OTP signing modal state
  const [signingPrev, setSigningPrev] = useState<Preventivo | null>(null);
  const [otpStep, setOtpStep] = useState<'send' | 'enter_code' | 'success'>('send');
  const [otpCode, setOtpCode] = useState('');
  const [otpSentCode, setOtpSentCode] = useState('');
  const [isOtpError, setIsOtpError] = useState(false);

  // Preventivi Filter state
  const [prevFilter, setPrevFilter] = useState<'attivi' | 'archiviati' | 'tutti'>('attivi');

  const handleCreatePreventivo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrevClient || !newPrevTitle) {
      alert('Per favore compila tutti i campi.');
      return;
    }

    const nextId = 'prev-' + Date.now();
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + Number(newPrevDays));

    const newPrev: Preventivo = {
      id: nextId,
      contactId: newPrevClient,
      codice: `PREV-2026-${Math.floor(100 + Math.random() * 900)}`,
      titolo: newPrevTitle,
      dataCreazione: new Date().toISOString().split('T')[0],
      dataScadenza: expDate.toISOString().split('T')[0],
      importo: Number(newPrevAmount),
      stato: 'elaborato',
      archiviato: false,
      firmaOtp: false,
      tecnicoAssegnato: newPrevTecnico
    };

    onAddPreventivo(newPrev);
    
    // Automatically move client to "preventivo" phase
    onUpdateContactPhase(newPrevClient, 'preventivo');

    setShowCreatePrevModal(false);
    setNewPrevClient('');
    setNewPrevTitle('');
    setNewPrevAmount(10000);
    setNewPrevDays(30);
  };

  const startOtpFlow = (prev: Preventivo) => {
    setSigningPrev(prev);
    setOtpStep('send');
    setOtpCode('');
    setIsOtpError(false);
  };

  const handleSendOtp = () => {
    const generated = Math.floor(1000 + Math.random() * 9000).toString();
    setOtpSentCode(generated);
    alert(`[Simulatore SMS OTP] Codice inviato al cellulare del cliente: ${generated}`);
    setOtpStep('enter_code');
  };

  const handleVerifyOtp = () => {
    if (otpCode === otpSentCode || otpCode === '1234') {
      setOtpStep('success');
      
      if (signingPrev) {
        // Mark quote as accepted
        const updated = {
          ...signingPrev,
          stato: 'accettato' as const,
          firmaOtp: true
        };
        onUpdatePreventivo(updated);

        // Auto move client to "contratto_firmato" phase
        onUpdateContactPhase(signingPrev.contactId, 'contratto_firmato');

        // Automatically assign technician task!
        const autoTask: AttivitaTecnico = {
          id: 'act-' + Date.now(),
          titolo: `Avviare pratica e rilievo per ${signingPrev.titolo}`,
          tecnico: signingPrev.tecnicoAssegnato,
          scadenza: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0],
          completata: false,
          contactId: signingPrev.contactId
        };
        onAddAttivita(autoTask);
      }
    } else {
      setIsOtpError(true);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50 overflow-hidden" id="commerciale-module">
      
      {/* Sub-header navigation */}
      <div className="bg-white border-b border-zinc-100 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-6">
          <button
            onClick={() => setSubSection('pipeline')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              subSection === 'pipeline' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
            id="sub-tab-pipeline"
          >
            Pipeline Commerciale
          </button>
          <button
            onClick={() => setSubSection('preventivi')}
            className={`text-sm font-semibold pb-1 border-b-2 transition-all ${
              subSection === 'preventivi' ? 'border-zinc-950 text-zinc-950' : 'border-transparent text-zinc-400 hover:text-zinc-600'
            }`}
            id="sub-tab-preventivi"
          >
            Registro Preventivi & Contratti
          </button>
        </div>

        <button
          onClick={() => setShowCreatePrevModal(true)}
          className="bg-zinc-950 text-white px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm hover:bg-zinc-800 self-start sm:self-auto"
          id="btn-trigger-create-prev"
        >
          <Plus className="h-4 w-4" /> Crea Preventivo
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        
        {/* PIPELINE VIEW */}
        {subSection === 'pipeline' && (
          <div className="space-y-6 h-full flex flex-col min-h-0" id="pipeline-panel">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Pipeline Lead & Avanzamento</h2>
                <p className="text-xs text-zinc-400 mt-0.5">Trascina o clicca per far progredire i contatti lungo il funnel commerciale.</p>
              </div>
              <div className="text-xs font-semibold bg-zinc-100 text-zinc-700 px-3 py-1.5 rounded-lg">
                VALORE STIMATO TOTALE: <span className="font-extrabold text-zinc-900">
                  {contacts.reduce((acc, curr) => acc + (curr.valorePipeline || 0), 0).toLocaleString('it-IT')} €
                </span>
              </div>
            </div>

            {/* Pipeline Columns Layout */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 flex-1 overflow-y-auto pb-6" id="pipeline-kanban-board">
              {STAGES.map((stage) => {
                const stageContacts = contacts.filter((c) => (c.fasePipeline || 'primo_contatto') === stage.id);
                return (
                  <div key={stage.id} className="bg-white rounded-xl border border-zinc-200/60 flex flex-col min-h-[300px]" id={`kanban-col-${stage.id}`}>
                    <div className="p-3 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50 rounded-t-xl shrink-0">
                      <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${stage.color}`}>
                        {stage.label}
                      </span>
                      <span className="text-xs font-bold text-zinc-400 font-mono">{stageContacts.length}</span>
                    </div>

                    <div className="p-2 space-y-2.5 flex-1 overflow-y-auto divide-y divide-zinc-100/50" id={`kanban-cards-${stage.id}`}>
                      {stageContacts.length === 0 ? (
                        <div className="text-[10px] text-zinc-300 italic text-center py-6">Nessun contatto</div>
                      ) : (
                        stageContacts.map((c) => (
                          <div key={c.id} className="p-3 bg-white hover:shadow-sm rounded-lg border border-zinc-100 space-y-2 transition-all" id={`kanban-card-${c.id}`}>
                            <div className="flex items-start justify-between gap-1">
                              <div>
                                <h4 className="text-xs font-bold text-zinc-800">{c.name} {c.surname}</h4>
                                {c.companyName && <p className="text-[10px] text-zinc-400 truncate">{c.companyName}</p>}
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[10px] pt-1">
                              <span className="font-extrabold text-zinc-900">{c.valorePipeline ? `${c.valorePipeline.toLocaleString()} €` : '0 €'}</span>
                              
                              {/* Fast stage forward button */}
                              <button
                                onClick={() => {
                                  const currentIdx = STAGES.findIndex((s) => s.id === stage.id);
                                  const nextIdx = (currentIdx + 1) % STAGES.length;
                                  onUpdateContactPhase(c.id, STAGES[nextIdx].id);
                                }}
                                className="text-zinc-400 hover:text-zinc-950 p-1 rounded-full hover:bg-zinc-100"
                                title="Avanza fase"
                              >
                                <ArrowRight className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* PREVENTIVI LIST SECTION */}
        {subSection === 'preventivi' && (
          <div className="space-y-6" id="preventivi-panel">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Registro Preventivi Elaborati</h2>
                <p className="text-xs text-zinc-400 mt-0.5">Gestione dei preventivi commerciali, scadenze, archiviazione e firma digitale OTP.</p>
              </div>

              {/* Status active/archived selector */}
              <div className="flex items-center gap-1.5 bg-zinc-100 p-1 rounded-lg text-xs" id="prev-archive-toggle">
                <button
                  onClick={() => setPrevFilter('attivi')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                    prevFilter === 'attivi' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <Briefcase className="h-3.5 w-3.5 inline mr-1" /> Attivi
                </button>
                <button
                  onClick={() => setPrevFilter('archiviati')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                    prevFilter === 'archiviati' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <Archive className="h-3.5 w-3.5 inline mr-1" /> Archiviati
                </button>
              </div>
            </div>

            {/* List Table */}
            <div className="bg-white rounded-xl border border-zinc-200/60 overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse" id="preventivi-table">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                    <th className="p-4">Codice</th>
                    <th className="p-4">Cliente / Richiedente</th>
                    <th className="p-4">Titolo Progetto</th>
                    <th className="p-4">Importo</th>
                    <th className="p-4">Scadenza</th>
                    <th className="p-4">Firma OTP</th>
                    <th className="p-4">Stato</th>
                    <th className="p-4 text-right">Azioni</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 text-xs">
                  {preventivi
                    .filter((p) => {
                      if (prevFilter === 'attivi') return !p.archiviato;
                      if (prevFilter === 'archiviati') return p.archiviato;
                      return true;
                    })
                    .map((p) => {
                      const client = contacts.find((c) => c.id === p.contactId);
                      return (
                        <tr key={p.id} className="hover:bg-zinc-50/50" id={`prev-row-${p.id}`}>
                          <td className="p-4 font-mono font-bold text-zinc-700">{p.codice}</td>
                          <td className="p-4 font-semibold text-zinc-900">
                            {client ? `${client.name} ${client.surname}` : 'Cliente rimosso'}
                          </td>
                          <td className="p-4 text-zinc-600 font-medium">{p.titolo}</td>
                          <td className="p-4 font-extrabold text-zinc-950">{p.importo.toLocaleString('it-IT')} €</td>
                          <td className="p-4 font-medium text-zinc-500">{p.dataScadenza}</td>
                          <td className="p-4">
                            {p.firmaOtp ? (
                              <span className="bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 w-fit border border-emerald-100">
                                <ShieldCheck className="h-3.5 w-3.5" /> FIRMATO OTP
                              </span>
                            ) : (
                              <span className="bg-amber-50 text-amber-600 px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 w-fit border border-amber-100">
                                <Clock className="h-3.5 w-3.5 animate-pulse" /> DA FIRMARE
                              </span>
                            )}
                          </td>
                          <td className="p-4">
                            <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              p.stato === 'accettato' ? 'bg-emerald-100 text-emerald-800' :
                              p.stato === 'elaborato' ? 'bg-indigo-100 text-indigo-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {p.stato}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {!p.firmaOtp && p.stato !== 'scaduto' && (
                                <button
                                  onClick={() => startOtpFlow(p)}
                                  className="bg-zinc-950 text-white px-2.5 py-1.5 rounded text-[10px] font-bold flex items-center gap-1 hover:bg-zinc-800"
                                  id={`btn-otp-sign-${p.id}`}
                                >
                                  <Smartphone className="h-3 w-3" /> Firma OTP
                                </button>
                              )}
                              <button
                                onClick={() => {
                                  onUpdatePreventivo({ ...p, archiviato: !p.archiviato });
                                }}
                                className="text-zinc-500 hover:text-zinc-900 p-1.5 hover:bg-zinc-100 rounded"
                                title={p.archiviato ? 'Ripristina' : 'Archivia'}
                              >
                                <Archive className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* CREATE PREVENTIVO MODAL OVERLAY */}
      <AnimatePresence>
        {showCreatePrevModal && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50" id="create-prev-modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
                <h3 className="text-base font-bold text-zinc-900">Nuovo Preventivo Commerciale</h3>
                <button onClick={() => setShowCreatePrevModal(false)} className="text-zinc-400 hover:text-zinc-600">✕</button>
              </div>

              <form onSubmit={handleCreatePreventivo} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Seleziona Cliente *</label>
                  <select
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50"
                    value={newPrevClient}
                    onChange={(e) => setNewPrevClient(e.target.value)}
                    required
                  >
                    <option value="">Scegli un contatto...</option>
                    {contacts.map((c) => (
                      <option key={c.id} value={c.id}>{c.name} {c.surname} ({c.companyName || c.categoria})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Titolo Oggetto Progetto *</label>
                  <input
                    type="text"
                    placeholder="Es. Nuova costruzione con piscina Ostuni"
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50"
                    value={newPrevTitle}
                    onChange={(e) => setNewPrevTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Importo (€) *</label>
                    <input
                      type="number"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50"
                      value={newPrevAmount}
                      onChange={(e) => setNewPrevAmount(Number(e.target.value))}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase">Validità (Giorni)</label>
                    <input
                      type="number"
                      className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-sm bg-zinc-50"
                      value={newPrevDays}
                      onChange={(e) => setNewPrevDays(Number(e.target.value))}
                    />
                  </div>
                </div>

                <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/50 space-y-2">
                  <span className="text-xs font-bold text-zinc-700 block">Sincronizzazione Automatica Attività</span>
                  <p className="text-[10px] text-zinc-400">All'accettazione del preventivo tramite firma OTP, verrà assegnata automaticamente un'attività operativa al seguente tecnico di riferimento.</p>
                  
                  <select
                    className="w-full p-2 border border-zinc-200 rounded text-xs bg-white focus:outline-none"
                    value={newPrevTecnico}
                    onChange={(e) => setNewPrevTecnico(e.target.value)}
                  >
                    <option value="Raffaele Zivoli">Raffaele Zivoli (Ingegnere)</option>
                    <option value="Claudia Turco">Claudia Turco (Architetto)</option>
                    <option value="Marco Epifani">Marco Epifani (Geometra)</option>
                    <option value="Ilaria Cavallo">Ilaria Cavallo (Ingegnere)</option>
                  </select>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-100">
                  <button type="button" onClick={() => setShowCreatePrevModal(false)} className="text-xs font-semibold text-zinc-500">Annulla</button>
                  <button type="submit" className="bg-zinc-950 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-sm hover:bg-zinc-800">Elabora Preventivo</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* OTP SMARTPHONE SIGNING DIALOG */}
      <AnimatePresence>
        {signingPrev && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50" id="otp-modal-overlay">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 border border-zinc-800 rounded-[40px] p-6 w-full max-w-[340px] text-white shadow-2xl relative"
              id="smartphone-mockup-frame"
            >
              {/* Phone Speaker & Camera Notch */}
              <div className="w-24 h-4 bg-zinc-950 rounded-full mx-auto mb-6 flex items-center justify-center gap-1 border border-zinc-800 shrink-0">
                <span className="w-1.5 h-1.5 bg-zinc-800 rounded-full"></span>
                <span className="w-10 h-1 bg-zinc-800 rounded-full"></span>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setSigningPrev(null)}
                className="absolute top-5 right-5 text-zinc-500 hover:text-white"
              >
                ✕
              </button>

              {/* Dynamic Steps */}
              <div className="space-y-4 text-center py-4" id="otp-flow-step-container">
                {otpStep === 'send' && (
                  <div className="space-y-5">
                    <Smartphone className="h-12 w-12 text-zinc-400 mx-auto animate-bounce" />
                    <div>
                      <h3 className="text-base font-bold">Firma Digitale OTP</h3>
                      <p className="text-[11px] text-zinc-400 mt-1">Convalida immediata tramite SMS OTP a norma di legge. Nessuna stampa necessaria.</p>
                    </div>

                    <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 text-left space-y-1">
                      <p className="text-[10px] text-zinc-500 font-bold uppercase">CODICE DOC</p>
                      <p className="text-xs font-mono font-bold text-white">{signingPrev.codice}</p>
                      <p className="text-[10px] text-zinc-500 font-bold uppercase mt-2">IMPORTO DA FIRMARE</p>
                      <p className="text-sm font-extrabold text-emerald-400">{signingPrev.importo.toLocaleString()} €</p>
                    </div>

                    <button
                      onClick={handleSendOtp}
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs py-3 rounded-xl shadow-md transition-all"
                    >
                      Invia Codice OTP via SMS
                    </button>
                  </div>
                )}

                {otpStep === 'enter_code' && (
                  <div className="space-y-5">
                    <ShieldCheck className="h-12 w-12 text-amber-400 mx-auto animate-pulse" />
                    <div>
                      <h3 className="text-base font-bold">Inserisci il Codice</h3>
                      <p className="text-[11px] text-zinc-400 mt-1">Abbiamo inviato un codice sul cellulare. Inseriscilo di seguito.</p>
                    </div>

                    <div className="space-y-2">
                      <input
                        type="text"
                        maxLength={4}
                        placeholder="----"
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        className="w-full bg-zinc-950 border border-zinc-800 text-center tracking-widest text-2xl font-bold py-3 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-400"
                      />
                      {isOtpError && (
                        <p className="text-xs text-red-400 font-semibold flex items-center justify-center gap-1">
                          <AlertCircle className="h-3.5 w-3.5" /> Codice errato! Riprova (usa 1234)
                        </p>
                      )}
                    </div>

                    <button
                      onClick={handleVerifyOtp}
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs py-3 rounded-xl shadow-md transition-all"
                    >
                      Verifica e Firma Contratto
                    </button>
                  </div>
                )}

                {otpStep === 'success' && (
                  <div className="space-y-5">
                    <div className="h-14 w-14 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
                      <CheckCircle className="h-8 w-8 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-emerald-400">Contratto Firmato!</h3>
                      <p className="text-[11px] text-zinc-400 mt-1">La firma digitale OTP è stata registrata con marca temporale.</p>
                    </div>

                    <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800/60 text-xs text-left space-y-1 text-zinc-300">
                      <p className="text-[10px] text-zinc-500 font-bold">TASK ASSEGNATO AUTOMATICAMENTE</p>
                      <p className="font-semibold text-white">⚙️ {signingPrev.tecnicoAssegnato}</p>
                      <p className="text-[10px] text-zinc-500 mt-2">Dettaglio:</p>
                      <p className="text-[10px] italic">"Avviare pratica e rilievo per {signingPrev.titolo}"</p>
                    </div>

                    <button
                      onClick={() => setSigningPrev(null)}
                      className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs py-2.5 rounded-xl transition-all"
                    >
                      Chiudi Portale
                    </button>
                  </div>
                )}
              </div>

              {/* Phone Home Button Pill */}
              <div className="w-28 h-1 bg-zinc-800 rounded-full mx-auto mt-6"></div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
