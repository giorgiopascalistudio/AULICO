/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, Clock, Plus, User, Info, CheckSquare } from 'lucide-react';

interface AgendaEvent {
  id: string;
  data: string;
  ora: string;
  titolo: string;
  tecnico: string;
  cliente: string;
}

interface AgendaViewProps {
  events: AgendaEvent[];
  onAddEvent: (ev: AgendaEvent) => void;
}

const WEEKDAYS = [
  { date: '2026-06-22', dayNum: '22', dayName: 'LUNEDÌ' },
  { date: '2026-06-23', dayNum: '23', dayName: 'MARTEDÌ' },
  { date: '2026-06-24', dayNum: '24', dayName: 'MERCOLEDÌ' },
  { date: '2026-06-25', dayNum: '25', dayName: 'GIOVEDÌ' },
  { date: '2026-06-26', dayNum: '26', dayName: 'VENERDÌ' },
  { date: '2026-06-27', dayNum: '27', dayName: 'SABATO' },
  { date: '2026-06-28', dayNum: '28', dayName: 'DOMENICA' }
];

export default function AgendaView({ events, onAddEvent }: AgendaViewProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [formDate, setFormDate] = useState('2026-06-22');
  const [formTime, setFormTime] = useState('10:00');
  const [formTitle, setFormTitle] = useState('');
  const [formTecnico, setFormTecnico] = useState('Raffaele Zivoli');
  const [formCliente, setFormCliente] = useState('');

  const [priorities, setPriorities] = useState([
    { id: 1, text: 'Verificare agibilità cantiere Vado Aperto' },
    { id: 2, text: 'Inviare preventivo ad Ayroldi Maria' },
    { id: 3, text: 'Accantonamento TFM trimestrale' }
  ]);
  const [newPriorityText, setNewPriorityText] = useState('');

  const handleAddEventSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formCliente) {
      alert('Per favore compila tutti i campi.');
      return;
    }

    const newEv: AgendaEvent = {
      id: 'ev-' + Date.now(),
      data: formDate,
      ora: formTime,
      titolo: formTitle,
      tecnico: formTecnico,
      cliente: formCliente
    };

    onAddEvent(newEv);
    setShowAddModal(false);
    setFormTitle('');
    setFormCliente('');
  };

  const handleAddPriority = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPriorityText) return;
    setPriorities([...priorities, { id: Date.now(), text: newPriorityText }]);
    setNewPriorityText('');
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-50 overflow-hidden" id="agenda-module">
      
      {/* Header bar */}
      <div className="bg-white border-b border-zinc-100 px-6 py-4 flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-lg font-bold text-zinc-900 tracking-tight">Agenda di Gruppo</h2>
          <p className="text-xs text-zinc-400 mt-0.5">Gestione settimanale degli appuntamenti tecnici e dei sopralluoghi sul territorio.</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-zinc-950 text-white px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 hover:bg-zinc-800 shadow-xs"
            id="btn-agenda-add-appointment"
          >
            <Plus className="h-4 w-4" /> Nuovo Appuntamento
          </button>
        </div>
      </div>

      {/* Main Weekly Agenda Grid replica of Page 2 layout */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        <div className="flex items-center justify-between shrink-0 mb-2">
          <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Settimana 22 Giu – 28 Giu 2026</span>
          <span className="text-[10px] text-indigo-600 font-extrabold bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">Visualizzazione Team attiva</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-8 gap-4" id="agenda-weekly-columns">
          
          {/* Calendar Day columns */}
          {WEEKDAYS.map((day) => {
            const dayEvents = events.filter((e) => e.data === day.date);
            return (
              <div key={day.date} className="bg-white rounded-2xl border border-zinc-200/60 p-4 flex flex-col h-[400px] shadow-2xs" id={`agenda-col-${day.date}`}>
                <div className="border-b border-zinc-100 pb-2 mb-3 text-center">
                  <p className="text-xl font-black text-zinc-900 leading-none">{day.dayNum}</p>
                  <p className="text-[9px] font-bold text-zinc-400 tracking-wider mt-1">{day.dayName}</p>
                </div>

                <div className="flex-1 overflow-y-auto space-y-2.5" id={`agenda-events-${day.date}`}>
                  {dayEvents.length === 0 ? (
                    <p className="text-[10px] text-zinc-300 italic text-center py-10">Libero</p>
                  ) : (
                    dayEvents.map((ev) => (
                      <div key={ev.id} className="p-2.5 bg-zinc-50 border border-zinc-100 rounded-xl space-y-1" id={`agenda-event-${ev.id}`}>
                        <div className="flex items-center gap-1 text-[9px] text-zinc-400 font-bold">
                          <Clock className="h-3 w-3" /> {ev.ora}
                        </div>
                        <h4 className="text-xs font-bold text-zinc-850 leading-tight">{ev.titolo}</h4>
                        <p className="text-[10px] text-zinc-500 font-medium">Cli: {ev.cliente}</p>
                        <span className="text-[9px] text-indigo-600 font-bold block pt-1 border-t border-zinc-100/30">
                          👤 {ev.tecnico}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}

          {/* PRIORITIES SIDE PANEL (Page 2) */}
          <div className="bg-white rounded-2xl border border-zinc-200/60 p-4 flex flex-col h-[400px] shadow-2xs lg:col-span-1" id="agenda-priorities-col">
            <div className="border-b border-zinc-100 pb-2 mb-3 text-center">
              <p className="text-sm font-black text-red-600 leading-none">PRIORITÀ'</p>
              <p className="text-[9px] font-bold text-zinc-400 tracking-wider mt-1">DA FARE QUESTA SETTIMANA</p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3" id="priorities-list">
              {priorities.map((p) => (
                <div key={p.id} className="flex items-start gap-2 bg-red-50/50 p-2 rounded-lg border border-red-100/40 text-[10px] font-medium text-zinc-800">
                  <CheckSquare className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                  <span>{p.text}</span>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddPriority} className="mt-4 pt-3 border-t border-zinc-100 space-y-2 shrink-0">
              <input
                type="text"
                placeholder="Aggiungi priorità..."
                value={newPriorityText}
                onChange={(e) => setNewPriorityText(e.target.value)}
                className="w-full p-2 border border-zinc-200 rounded text-[10px] bg-zinc-50 focus:outline-none"
              />
              <button type="submit" className="w-full bg-zinc-900 hover:bg-zinc-800 text-white text-[10px] py-1.5 rounded font-bold">
                Aggiungi Priorità
              </button>
            </form>
          </div>

        </div>
      </div>

      {/* APPOINTMENT MODAL OVERLAY */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <h3 className="text-base font-bold text-zinc-900">Registra Appuntamento</h3>
              <button onClick={() => setShowAddModal(false)} className="text-zinc-400 hover:text-zinc-600">✕</button>
            </div>

            <form onSubmit={handleAddEventSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Data *</label>
                  <select
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                  >
                    {WEEKDAYS.map((d) => (
                      <option key={d.date} value={d.date}>{d.dayNum} Giugno ({d.dayName.toLowerCase()})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase">Ora *</label>
                  <input
                    type="time"
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase">Titolo Visita / Sopralluogo *</label>
                <input
                  type="text"
                  placeholder="Es. Verifica muretti a secco"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase">Cliente / Richiedente *</label>
                <input
                  type="text"
                  placeholder="Es. Gioia Mariagrazia"
                  value={formCliente}
                  onChange={(e) => setFormCliente(e.target.value)}
                  className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase">Tecnico Incaricato</label>
                <select
                  value={formTecnico}
                  onChange={(e) => setFormTecnico(e.target.value)}
                  className="w-full mt-1 p-2 border border-zinc-200 rounded-lg text-xs font-semibold bg-zinc-50"
                >
                  <option value="Raffaele Zivoli">Raffaele Zivoli</option>
                  <option value="Claudia Turco">Claudia Turco</option>
                  <option value="Marco Epifani">Marco Epifani</option>
                  <option value="Francesco Zurlo">Francesco Zurlo</option>
                  <option value="Ilaria Cavallo">Ilaria Cavallo</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-100">
                <button type="button" onClick={() => setShowAddModal(false)} className="text-xs font-semibold text-zinc-500">Annulla</button>
                <button type="submit" className="bg-zinc-950 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-xs">Salva</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
