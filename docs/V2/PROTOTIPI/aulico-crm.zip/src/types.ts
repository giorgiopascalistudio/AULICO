/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Societa {
  STRATEGICO = 'STRATEGICO',
  UNICO = 'UNICO',
  ONIRICO = 'ONIRICO',
  MATERICO = 'MATERICO',
  FANTASTICO = 'FANTASTICO'
}

export type CategoriaPersone =
  | 'Clienti'
  | 'Investitori'
  | 'Fornitori e Imprese'
  | 'Agenzie Immobiliari'
  | 'Sponsor e Conoscenti'
  | 'Figure Istituzionali';

export interface BrandAsset {
  obiettivi: string;
  tonoVoce: string;
  targetRiferimento: string;
  assetGrafici: string[]; // Mock file names
}

export interface Credential {
  id: string;
  service: string;
  username: string;
  password; // Plain for demo, but protected visually
  note: string;
}

export interface Interazione {
  id: string;
  tipo: 'riunione' | 'evento' | 'campagna' | 'regalo';
  data: string;
  titolo: string;
  descrizione: string;
  dettagliAggiuntivi?: string; // e.g. "Regalo di Natale", "Sito web", "Inviata newsletter"
}

export interface Contact {
  id: string;
  name: string;
  surname: string;
  companyName?: string;
  cfPiva?: string;
  email: string;
  phone: string;
  indirizzo: string;
  societaCollegate: Societa[]; // checkboxes, can belong to multiple
  categoria: CategoriaPersone;
  
  // Specific subtypes
  statoCliente?: 'attivo' | 'lead' | 'ex';
  investitoreTipo?: 'attivo' | 'potenziale';
  fornitoreTipo?: 'subappaltatore' | 'artigiano' | 'altro';
  
  // Profilazione
  targetCategoria: string; // e.g. "Imprese di Ostuni", "Agenzie immobiliari", "Privato"
  fasciaImportanza: 1 | 2 | 3; // Fascia 1, 2, 3 based on deal value
  canaleAcquisizione: 'social' | 'sito' | 'passaparola' | 'agenzia' | 'altro';
  
  // Operating data
  brandAsset?: BrandAsset;
  credenziali: Credential[];
  liberatoriaPrivacyFirmata: boolean; // if false, shows flashing red warning alert!
  
  // Memoria storica
  interazioni: Interazione[];
  
  // Financial & Commercial status
  fasePipeline: 'primo_contatto' | 'attesa_preventivo' | 'preventivo' | 'negoziazione' | 'contratto_firmato' | 'perso';
  valorePipeline: number;
  regolaritaPagamenti: boolean; // true = green dot, false = red dot (blocks document download)
  saldoDovuto: number;
  dataCreazione: string;
  progettoId?: string; // matches a construction project if applicable
}

export interface Preventivo {
  id: string;
  contactId: string;
  codice: string;
  titolo: string;
  dataCreazione: string;
  dataScadenza: string;
  importo: number;
  stato: 'elaborato' | 'accettato' | 'scaduto';
  archiviato: boolean;
  firmaOtp: boolean; // requires OTP signature simulation
  tecnicoAssegnato: string; // auto activities assigned
}

export interface AttivitaTecnico {
  id: string;
  titolo: string;
  tecnico: string;
  scadenza: string;
  completata: boolean;
  contactId: string;
}

export interface DocumentoCliente {
  id: string;
  nome: string;
  categoria: string; // e.g. "04-Pratiche", "12-Agibilità"
  sensibile: boolean; // if true, blocked if contact has regolaritaPagamenti === false
  dataCaricamento: string;
  tipo: string;
  size: string;
}

// Finance schema for "Amministrazione" / "Contabilità"
export interface FlussoMese {
  mese: string; // e.g. "Gennaio", "Febbraio"
  preventivato: number;
  venduto: number;
  fatturato: number;
  incassato: number;
  erogato: number;
  liquidita: number;
  costiFissi: number;
  costiVariabili: number;
}

export interface CollaboratoreIncentivo {
  nome: string;
  puntiMese: { [mese: string]: number };
}
